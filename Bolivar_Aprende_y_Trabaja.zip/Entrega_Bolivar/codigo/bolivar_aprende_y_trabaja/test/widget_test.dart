import 'package:flutter_test/flutter_test.dart';
import 'package:bolivar_aprende_y_trabaja/main.dart';

void main() {
  testWidgets('La app arranca en la pantalla de login', (WidgetTester tester) async {
    await tester.pumpWidget(const BolivarApp());
    expect(find.text('Iniciar sesión'), findsWidgets);
  });
}
