import 'package:flutter/material.dart';

// Colores del diseño (los mismos de la app anterior).
const azulOscuro = Color(0xFF1E2A47);
const naranjaAcento = Color(0xFFFF8A00);
const grisTexto = Color(0xFF6B7280);
const grisFondo = Color(0xFFF7F7F8);
const grisBorde = Color(0xFFEDEDED);
const rojoCerrar = Color(0xFFDC3545);
const verdeOk = Color(0xFF2E7D32);
const moradoMenu = Color(0xFF241B3D);
const amarilloBadge = Color(0xFFF3C64B);
const lilaSeleccion = Color(0xFFF3F0FF);

ThemeData temaPrincipal() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: azulOscuro,
      primary: azulOscuro,
      secondary: naranjaAcento,
    ),
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      elevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: azulOscuro, width: 1.4),
      ),
      hintStyle: const TextStyle(color: Color(0xFFB0B3B8), fontSize: 13),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: azulOscuro,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
      ),
    ),
  );
}
