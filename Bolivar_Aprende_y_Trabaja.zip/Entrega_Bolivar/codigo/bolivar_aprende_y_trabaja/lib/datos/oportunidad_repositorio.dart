import '../datos/api_cliente.dart';
import '../datos/modelos.dart';

// CRUD de ofertas académicas y laborales contra la API:
//   GET    /api/ofertas-academicas        GET    /api/ofertas-laborales
//   POST   /api/ofertas-academicas        POST   /api/ofertas-laborales
//   PUT    /api/ofertas-academicas/:id    PUT    /api/ofertas-laborales/:id
//   DELETE /api/ofertas-academicas/:id    DELETE /api/ofertas-laborales/:id
class OportunidadRepositorio {
  // ---------- GET ----------
  Future<List<OfertaAcademica>> academicas() async {
    try {
      final r = await ApiCliente.get('/ofertas-academicas') as List;
      return r.map((m) => OfertaAcademica.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  Future<List<OfertaLaboral>> laborales() async {
    try {
      final r = await ApiCliente.get('/ofertas-laborales') as List;
      return r.map((m) => OfertaLaboral.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  // ---------- POST ----------
  Future<bool> agregarAcademica(OfertaAcademica o) async {
    await ApiCliente.post('/ofertas-academicas', {
      'nombre': o.nombre.trim(),
      'descripcion': o.descripcion.trim(),
      'requisitos': o.requisitos.trim(),
      'cupos': o.cupos,
    });
    return true;
  }

  Future<bool> agregarLaboral(OfertaLaboral o) async {
    await ApiCliente.post('/ofertas-laborales', {
      'empresa': o.empresa.trim(),
      'cargo': o.cargo.trim(),
      'descripcion': o.descripcion.trim(),
      'requisitos': o.requisitos.trim(),
      'ubicacion': o.ubicacion.trim(),
      'salario': o.salario.trim(),
      'fecha_publicacion': o.fechaPublicacion,
      'contacto': o.contacto.trim(),
    });
    return true;
  }

  // ---------- PUT ----------
  Future<bool> editarAcademica(OfertaAcademica o) async {
    await ApiCliente.put('/ofertas-academicas/${o.id}', {
      'nombre': o.nombre.trim(),
      'descripcion': o.descripcion.trim(),
      'requisitos': o.requisitos.trim(),
      'cupos': o.cupos,
    });
    return true;
  }

  Future<bool> editarLaboral(OfertaLaboral o) async {
    await ApiCliente.put('/ofertas-laborales/${o.id}', {
      'empresa': o.empresa.trim(),
      'cargo': o.cargo.trim(),
      'descripcion': o.descripcion.trim(),
      'requisitos': o.requisitos.trim(),
      'ubicacion': o.ubicacion.trim(),
      'salario': o.salario.trim(),
      'contacto': o.contacto.trim(),
    });
    return true;
  }

  // ---------- DELETE ----------
  Future<bool> eliminarAcademica(int id) async {
    await ApiCliente.delete('/ofertas-academicas/$id');
    return true;
  }

  Future<bool> eliminarLaboral(int id) async {
    await ApiCliente.delete('/ofertas-laborales/$id');
    return true;
  }
}
