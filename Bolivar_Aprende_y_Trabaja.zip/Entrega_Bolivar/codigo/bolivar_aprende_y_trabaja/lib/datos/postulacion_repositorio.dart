import '../datos/api_cliente.dart';
import '../datos/modelos.dart';

// Postulaciones a ofertas laborales (API /api/postulaciones).
class PostulacionRepositorio {
  Future<bool> postularse(int usuarioId, int ofertaId) async {
    try {
      await ApiCliente.post('/postulaciones', {'usuario_id': usuarioId, 'oferta_id': ofertaId});
      return true;
    } on ApiException catch (e) {
      if (e.codigo == 409) return false; // ya estaba postulado
      rethrow;
    }
  }

  Future<List<Postulacion>> listarPorUsuario(int usuarioId) async {
    try {
      final r = await ApiCliente.get('/postulaciones', consulta: {'usuarioId': '$usuarioId'}) as List;
      return r.map((m) => Postulacion.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  // Todas las postulaciones (las ve el administrador), con datos del estudiante.
  Future<List<PostulacionRecibida>> todas() async {
    try {
      final r = await ApiCliente.get('/postulaciones') as List;
      return r.map((m) => PostulacionRecibida.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  // El administrador cambia el estado de una postulación (PUT) y la API avisa al estudiante.
  Future<bool> cambiarEstado(int postulacionId, String estado) async {
    try {
      await ApiCliente.put('/postulaciones/$postulacionId', {'estado': estado});
      return true;
    } on ApiException {
      return false;
    }
  }
}
