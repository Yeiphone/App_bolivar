import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Error de la API: falla de conexión o respuesta con error (400, 404, 409...).
class ApiException implements Exception {
  final String mensaje;
  final int? codigo;
  const ApiException(this.mensaje, [this.codigo]);

  bool get sinConexion => codigo == null;

  @override
  String toString() => mensaje;
}

// Cliente HTTP único de la app: todos los repositorios pasan por aquí.
class ApiCliente {
  // 10.0.2.2 es el "localhost" de tu PC visto desde el emulador de Android.
  // En un celular real se cambia desde la pantalla de login (ícono de ajustes)
  // por la IP de la PC, por ejemplo http://192.168.1.10:3000
  static const urlPorDefecto = 'http://10.0.2.2:3000';
  static const _clave = 'api_url';
  static const _tiempoMax = Duration(seconds: 10);

  static String _base = urlPorDefecto;

  static String get urlBase => _base;

  static Future<void> cargarUrl() async {
    final prefs = await SharedPreferences.getInstance();
    _base = prefs.getString(_clave) ?? urlPorDefecto;
  }

  static Future<void> guardarUrl(String url) async {
    var limpia = url.trim();
    if (limpia.isEmpty) limpia = urlPorDefecto;
    if (!limpia.startsWith('http://') && !limpia.startsWith('https://')) {
      limpia = 'http://$limpia';
    }
    while (limpia.endsWith('/')) {
      limpia = limpia.substring(0, limpia.length - 1);
    }
    _base = limpia;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_clave, limpia);
  }

  static Uri _uri(String ruta, [Map<String, String>? consulta]) {
    final u = Uri.parse('$_base/api$ruta');
    return consulta == null ? u : u.replace(queryParameters: consulta);
  }

  static Future<dynamic> get(String ruta, {Map<String, String>? consulta}) =>
      _enviar(() => http.get(_uri(ruta, consulta)));

  static Future<dynamic> post(String ruta, Map<String, Object?> cuerpo) => _enviar(
        () => http.post(_uri(ruta), headers: _json, body: jsonEncode(cuerpo)),
      );

  static Future<dynamic> put(String ruta, Map<String, Object?> cuerpo,
          {Map<String, String>? consulta}) =>
      _enviar(
        () => http.put(_uri(ruta, consulta), headers: _json, body: jsonEncode(cuerpo)),
      );

  static Future<dynamic> delete(String ruta, {Map<String, String>? consulta}) =>
      _enviar(() => http.delete(_uri(ruta, consulta)));

  static const _json = {'Content-Type': 'application/json'};

  static Future<dynamic> _enviar(Future<http.Response> Function() peticion) async {
    final http.Response r;
    try {
      r = await peticion().timeout(_tiempoMax);
    } on TimeoutException {
      throw const ApiException('El servidor tardó demasiado en responder');
    } on SocketException {
      throw ApiException('No se pudo conectar con el servidor ($_base)');
    } on http.ClientException {
      throw ApiException('No se pudo conectar con el servidor ($_base)');
    }

    final cuerpo = r.body.isEmpty ? null : jsonDecode(utf8.decode(r.bodyBytes));
    if (r.statusCode >= 200 && r.statusCode < 300) return cuerpo;

    final msg = (cuerpo is Map && cuerpo['error'] != null)
        ? cuerpo['error'].toString()
        : 'Error del servidor (${r.statusCode})';
    throw ApiException(msg, r.statusCode);
  }
}
