import '../datos/api_cliente.dart';
import '../datos/modelos.dart';

// Notificaciones (API /api/notificaciones).
class NotificacionRepositorio {
  Future<List<Notificacion>> listarPorUsuario(int usuarioId) async {
    try {
      final r = await ApiCliente.get('/notificaciones', consulta: {'usuarioId': '$usuarioId'}) as List;
      return r.map((m) => Notificacion.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  // Últimas alertas enviadas (panel del administrador).
  Future<List<Notificacion>> recientes({int limite = 10}) async {
    try {
      final r = await ApiCliente.get('/notificaciones', consulta: {'limite': '$limite'}) as List;
      return r.map((m) => Notificacion.desdeMapa(Map<String, Object?>.from(m as Map))).toList();
    } on ApiException {
      return [];
    }
  }

  Future<void> marcarTodasComoLeidas(int usuarioId) async {
    try {
      await ApiCliente.put('/notificaciones/leidas', {}, consulta: {'usuarioId': '$usuarioId'});
    } on ApiException {
      // no es crítico: se reintenta la próxima vez que abra las notificaciones
    }
  }

  Future<bool> crear({
    required int usuarioId,
    required String titulo,
    required String mensaje,
    String icono = 'notificacion',
  }) async {
    await ApiCliente.post('/notificaciones', {
      'usuario_id': usuarioId,
      'titulo': titulo.trim(),
      'mensaje': mensaje.trim(),
      'icono': icono,
    });
    return true;
  }

  Future<bool> eliminar(int id) async {
    await ApiCliente.delete('/notificaciones/$id');
    return true;
  }

  // Notificación a todos los usuarios registrados (la usa el admin con "Alertas").
  Future<int> crearParaTodos({required String titulo, required String mensaje, String icono = 'notificacion'}) async {
    final r = await ApiCliente.post('/notificaciones/todos', {
      'titulo': titulo.trim(),
      'mensaje': mensaje.trim(),
      'icono': icono,
    });
    return (r as Map)['enviadas'] as int;
  }
}
