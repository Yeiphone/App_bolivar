import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Foto de perfil: se elige de la galería, se copia a una carpeta de la app
// (para que no se borre si el teléfono limpia la caché) y la ruta se guarda
// en SharedPreferences con la clave "foto_<usuarioId>".
class FotoPerfil {
  static String _clave(int usuarioId) => 'foto_$usuarioId';

  static Future<String?> ruta(int usuarioId) async {
    final prefs = await SharedPreferences.getInstance();
    final ruta = prefs.getString(_clave(usuarioId));
    if (ruta == null) return null;
    if (!File(ruta).existsSync()) return null; // borrada por el sistema
    return ruta;
  }

  /// Abre la galería y guarda la foto elegida. Devuelve la nueva ruta
  /// o null si el usuario canceló.
  static Future<String?> cambiar(int usuarioId) async {
    final elegida = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 900,
      imageQuality: 85,
    );
    if (elegida == null) return null; // canceló

    final dir = await getApplicationDocumentsDirectory();
    final destino = File('${dir.path}/perfil_$usuarioId.jpg');
    await File(elegida.path).copy(destino.path);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_clave(usuarioId), destino.path);
    return destino.path;
  }
}
