import '../datos/api_cliente.dart';
import '../datos/modelos.dart';

// Usuarios: registro e inicio de sesión contra la API.
class UsuarioRepositorio {
  // Devuelve false si el correo ya existe. Si no hay conexión lanza ApiException.
  Future<bool> registrar({
    required String nombre,
    required String apellido,
    required String identificacion,
    required String correo,
    required String telefono,
    required String municipio,
    required String password,
    required String tipoPerfil,
  }) async {
    try {
      await ApiCliente.post('/usuarios', {
        'nombre': nombre.trim(),
        'apellido': apellido.trim(),
        'identificacion': identificacion.trim(),
        'correo': correo.trim(),
        'telefono': telefono.trim(),
        'municipio': municipio.trim(),
        'password': password,
        'tipoPerfil': tipoPerfil,
      });
      return true;
    } on ApiException catch (e) {
      if (e.codigo == 409) return false; // correo repetido
      rethrow;
    }
  }

  // Devuelve null si las credenciales son incorrectas. Si no hay conexión lanza ApiException.
  Future<Usuario?> iniciarSesion(String correo, String password) async {
    try {
      final r = await ApiCliente.post('/auth/login', {
        'correo': correo.trim(),
        'password': password.trim(),
      });
      return Usuario.desdeMapa(Map<String, Object?>.from(r as Map));
    } on ApiException catch (e) {
      if (e.codigo == 401) return null;
      rethrow;
    }
  }

  Future<Usuario?> porId(int id) async {
    try {
      final r = await ApiCliente.get('/usuarios/$id');
      return Usuario.desdeMapa(Map<String, Object?>.from(r as Map));
    } on ApiException {
      return null;
    }
  }

  Future<List<Map<String, Object?>>> listar() async {
    try {
      final r = await ApiCliente.get('/usuarios') as List;
      return r.map((m) => Map<String, Object?>.from(m as Map)).toList();
    } on ApiException {
      return [];
    }
  }

  Future<int> contar() async => (await listar()).length;
}
