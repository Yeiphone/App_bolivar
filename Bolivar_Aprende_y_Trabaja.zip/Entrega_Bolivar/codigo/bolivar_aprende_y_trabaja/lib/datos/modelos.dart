// Modelos de los datos que vienen de la base.
class Usuario {
  final int id;
  final String nombre;
  final String apellido;
  final String correo;
  final String municipio;
  final String tipoPerfil;
  final bool esAdministrador;

  const Usuario({
    required this.id,
    required this.nombre,
    required this.apellido,
    required this.correo,
    required this.municipio,
    required this.tipoPerfil,
    required this.esAdministrador,
  });

  String get nombreCompleto => '$nombre $apellido'.trim();

  factory Usuario.desdeMapa(Map<String, Object?> m) => Usuario(
        id: m['id'] as int,
        nombre: (m['nombre'] ?? '') as String,
        apellido: (m['apellido'] ?? '') as String,
        correo: (m['correo'] ?? '') as String,
        municipio: (m['municipio'] ?? '') as String,
        tipoPerfil: (m['tipoPerfil'] ?? '') as String,
        esAdministrador: (m['esAdministrador'] ?? 0) == 1,
      );
}

class OfertaAcademica {
  final int id;
  final String nombre;
  final String descripcion;
  final String requisitos;
  final int cupos;

  const OfertaAcademica({
    required this.id,
    required this.nombre,
    required this.descripcion,
    required this.requisitos,
    required this.cupos,
  });

  factory OfertaAcademica.desdeMapa(Map<String, Object?> m) => OfertaAcademica(
        id: m['id'] as int,
        nombre: (m['nombre'] ?? '') as String,
        descripcion: (m['descripcion'] ?? '') as String,
        requisitos: (m['requisitos'] ?? '') as String,
        cupos: (m['cupos'] ?? 0) as int,
      );
}

class OfertaLaboral {
  final int id;
  final String empresa;
  final String cargo;
  final String descripcion;
  final String requisitos;
  final String ubicacion;
  final String salario;
  final String fechaPublicacion;
  final String contacto;

  const OfertaLaboral({
    required this.id,
    required this.empresa,
    required this.cargo,
    required this.descripcion,
    required this.requisitos,
    required this.ubicacion,
    required this.salario,
    required this.fechaPublicacion,
    required this.contacto,
  });

  factory OfertaLaboral.desdeMapa(Map<String, Object?> m) => OfertaLaboral(
        id: m['id'] as int,
        empresa: (m['empresa'] ?? '') as String,
        cargo: (m['cargo'] ?? '') as String,
        descripcion: (m['descripcion'] ?? '') as String,
        requisitos: (m['requisitos'] ?? '') as String,
        ubicacion: (m['ubicacion'] ?? '') as String,
        salario: (m['salario'] ?? '') as String,
        fechaPublicacion: (m['fecha_publicacion'] ?? '') as String,
        contacto: (m['contacto'] ?? '') as String,
      );
}

class Notificacion {
  final int id;
  final String icono;
  final String titulo;
  final String mensaje;
  final int fechaMillis;
  final bool leida;

  const Notificacion({
    required this.id,
    required this.icono,
    required this.titulo,
    required this.mensaje,
    required this.fechaMillis,
    required this.leida,
  });

  factory Notificacion.desdeMapa(Map<String, Object?> m) => Notificacion(
        id: m['id'] as int,
        icono: (m['icono'] ?? 'notificacion') as String,
        titulo: (m['titulo'] ?? '') as String,
        mensaje: (m['mensaje'] ?? '') as String,
        fechaMillis: int.tryParse((m['fechaEnvio'] ?? '0') as String) ?? 0,
        leida: (m['leida'] ?? 0) == 1,
      );
}

class Postulacion {
  final int id;
  final int ofertaId;
  final String empresa;
  final String cargo;
  final int fechaMillis;
  final String estado;

  const Postulacion({
    required this.id,
    required this.ofertaId,
    required this.empresa,
    required this.cargo,
    required this.fechaMillis,
    required this.estado,
  });

  factory Postulacion.desdeMapa(Map<String, Object?> m) => Postulacion(
        id: m['id'] as int,
        ofertaId: (m['oferta_id'] ?? 0) as int,
        empresa: (m['empresa'] ?? '') as String,
        cargo: (m['cargo'] ?? '') as String,
        fechaMillis: int.tryParse((m['fecha_postulacion'] ?? '0') as String) ?? 0,
        estado: (m['estado'] ?? 'Enviada') as String,
      );
}

// Postulación recibida por el administrador (viene con datos del estudiante).
class PostulacionRecibida {
  final int id;
  final int usuarioId;
  final int ofertaId;
  final String estudiante;
  final String correo;
  final String cargo;
  final String empresa;
  final int fechaMillis;
  final String estado;

  const PostulacionRecibida({
    required this.id,
    required this.usuarioId,
    required this.ofertaId,
    required this.estudiante,
    required this.correo,
    required this.cargo,
    required this.empresa,
    required this.fechaMillis,
    required this.estado,
  });

  factory PostulacionRecibida.desdeMapa(Map<String, Object?> m) => PostulacionRecibida(
        id: m['id'] as int,
        usuarioId: (m['usuario_id'] ?? 0) as int,
        ofertaId: (m['oferta_id'] ?? 0) as int,
        estudiante: (m['estudiante'] ?? '') as String,
        correo: (m['correo'] ?? '') as String,
        cargo: (m['cargo'] ?? '') as String,
        empresa: (m['empresa'] ?? '') as String,
        fechaMillis: int.tryParse((m['fecha_postulacion'] ?? '0') as String) ?? 0,
        estado: (m['estado'] ?? 'Enviada') as String,
      );
}
