import '../datos/api_cliente.dart';
import '../datos/modelos.dart';

// Inscripciones del estudiante a ofertas académicas (API /api/inscripciones).
class InscripcionRepositorio {
  Future<bool> inscribirse(int usuarioId, int ofertaId) async {
    try {
      await ApiCliente.post('/inscripciones', {'usuario_id': usuarioId, 'oferta_id': ofertaId});
      return true;
    } on ApiException catch (e) {
      if (e.codigo == 409) return false; // ya estaba inscrito
      rethrow;
    }
  }

  Future<bool> anular(int usuarioId, int ofertaId) async {
    try {
      await ApiCliente.delete('/inscripciones',
          consulta: {'usuarioId': '$usuarioId', 'ofertaId': '$ofertaId'});
      return true;
    } on ApiException {
      return false;
    }
  }

  Future<List<Map<String, Object?>>> _mias(int usuarioId) async {
    try {
      final r = await ApiCliente.get('/inscripciones', consulta: {'usuarioId': '$usuarioId'}) as List;
      return r.map((m) => Map<String, Object?>.from(m as Map)).toList();
    } on ApiException {
      return [];
    }
  }

  // Ofertas académicas en las que el usuario está inscrito.
  Future<List<OfertaAcademica>> misInscripciones(int usuarioId) async {
    final filas = await _mias(usuarioId);
    return filas
        .map((f) => OfertaAcademica.desdeMapa(Map<String, Object?>.from(f['oferta'] as Map)))
        .toList();
  }

  // Ids de las ofertas académicas en las que está inscrito (para marcar "Inscrito").
  Future<Set<int>> idsInscritos(int usuarioId) async {
    final filas = await _mias(usuarioId);
    return filas.map((f) => f['oferta_id'] as int).toSet();
  }
}
