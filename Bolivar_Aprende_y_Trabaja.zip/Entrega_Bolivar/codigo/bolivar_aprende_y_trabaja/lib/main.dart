import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'datos/api_cliente.dart';
import 'datos/modelos.dart';
import 'datos/usuario_repositorio.dart';
import 'pantallas/home.dart';
import 'pantallas/login.dart';
import 'pantallas/registro.dart';
import 'tema.dart';

// Llave global del navegador: permite navegar desde cualquier parte
// (por ejemplo al cerrar sesión), aunque el widget que lanzó la acción ya no exista.
final navegadorGlobal = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ApiCliente.cargarUrl();
  runApp(const BolivarApp());
}

class BolivarApp extends StatelessWidget {
  const BolivarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bolívar Aprende y Trabaja',
      debugShowCheckedModeBanner: false,
      navigatorKey: navegadorGlobal,
      theme: temaPrincipal(),
      home: const SesionIniciada(),
    );
  }
}

// Decide por dónde empieza: si hay sesión guardada entra al Home,
// si no, muestra el login.
class SesionIniciada extends StatefulWidget {
  const SesionIniciada({super.key});

  @override
  State<SesionIniciada> createState() => _SesionIniciadaState();
}

class _SesionIniciadaState extends State<SesionIniciada> {
  @override
  void initState() {
    super.initState();
    _revisarSesion();
  }

  Future<void> _revisarSesion() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('usuario_id');
    if (id == null) {
      if (mounted) setState(() {});
      return;
    }
    final repo = UsuarioRepositorio();
    final usuario = await repo.porId(id);
    if (mounted && usuario != null) {
      _entrar(usuario);
    } else if (mounted) {
      setState(() {});
    }
  }

  void _entrar(Usuario u) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => HomePantalla(
          usuario: u,
          onCerrarSesion: () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('usuario_id');
            // Se usa la llave global: el widget de este cierre ya no existe,
            // por eso con Navigator.of(context) no se llegaba al login.
            navegadorGlobal.currentState?.pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const SesionIniciada()),
              (_) => false,
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LoginPantalla(
      onEntrar: (u) async {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt('usuario_id', u.id);
        _entrar(u);
      },
      onCrearCuenta: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => RegistroPantalla(
              onRegistrado: () {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const SesionIniciada()),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
