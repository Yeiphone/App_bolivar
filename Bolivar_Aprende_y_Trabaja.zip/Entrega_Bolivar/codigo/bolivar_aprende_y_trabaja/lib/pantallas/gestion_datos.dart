import 'package:flutter/material.dart';
import '../componentes.dart';
import '../datos/api_cliente.dart';
import '../datos/modelos.dart';
import '../datos/notificacion_repositorio.dart';
import '../datos/oportunidad_repositorio.dart';
import '../datos/usuario_repositorio.dart';
import '../tema.dart';

// Pantalla de gestión: pestaña de oportunidades (crear/borrar) y pestaña de alertas.
class GestionDatosPantalla extends StatefulWidget {
  final int pestanaInicial;
  const GestionDatosPantalla({super.key, this.pestanaInicial = 0});

  @override
  State<GestionDatosPantalla> createState() => _GestionDatosPantallaState();
}

class _GestionDatosPantallaState extends State<GestionDatosPantalla> {
  int _pestana = 0;

  @override
  void initState() {
    super.initState();
    _pestana = widget.pestanaInicial;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Gestión de datos', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(44),
          child: Row(
            children: [
              _botonPestana('Oportunidades', 0),
              _botonPestana('Alertas', 1),
            ],
          ),
        ),
      ),
      body: _pestana == 0 ? const _PestanaOportunidades() : const _PestanaAlertas(),
    );
  }

  Widget _botonPestana(String texto, int i) {
    final sel = _pestana == i;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _pestana = i),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: sel ? azulOscuro : Colors.transparent, width: 2),
            ),
          ),
          child: Text(
            texto,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              fontWeight: sel ? FontWeight.w600 : FontWeight.normal,
              color: sel ? azulOscuro : grisTexto,
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------- Oportunidades ----------------

class _PestanaOportunidades extends StatefulWidget {
  const _PestanaOportunidades();

  @override
  State<_PestanaOportunidades> createState() => _PestanaOportunidadesState();
}

class _PestanaOportunidadesState extends State<_PestanaOportunidades> {
  final _repo = OportunidadRepositorio();
  int _tipo = 0; // 0 = académica, 1 = laboral
  int _version = 0;

  late Future<List<OfertaAcademica>> _academicas;
  late Future<List<OfertaLaboral>> _laborales;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  void _cargar() {
    _academicas = _repo.academicas();
    _laborales = _repo.laborales();
  }

  void _refrescar() {
    setState(() {
      _version++;
      _cargar();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        Row(
          children: [
            _chip('Académica', 0),
            const SizedBox(width: 8),
            _chip('Laboral', 1),
          ],
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => _abrirFormulario(),
          style: FilledButton.styleFrom(backgroundColor: naranjaAcento),
          icon: const Icon(Icons.add, size: 18),
          label: Text(_tipo == 0 ? 'Nueva oportunidad académica' : 'Nueva oferta laboral',
              style: const TextStyle(fontSize: 13)),
        ),
        const SizedBox(height: 20),
        Text(_tipo == 0 ? 'Cursos publicados' : 'Ofertas publicadas',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 10),
        if (_tipo == 0)
          FutureBuilder<List<OfertaAcademica>>(
            future: _academicas,
            key: ValueKey('ga$_version'),
            builder: (c, s) {
              if (!s.hasData) return const TextoVacio('Cargando...');
              if (s.data!.isEmpty) return const TextoVacio('No hay cursos publicados.');
              return Column(children: [
                for (final o in s.data!)
                  _filaBorrable(o.nombre, o.descripcion, () => _abrirFormulario(academica: o), () async {
                    await _ejecutar(() => _repo.eliminarAcademica(o.id), 'Oportunidad eliminada');
                  }),
              ]);
            },
          )
        else
          FutureBuilder<List<OfertaLaboral>>(
            future: _laborales,
            key: ValueKey('gl$_version'),
            builder: (c, s) {
              if (!s.hasData) return const TextoVacio('Cargando...');
              if (s.data!.isEmpty) return const TextoVacio('No hay ofertas publicadas.');
              return Column(children: [
                for (final o in s.data!)
                  _filaBorrable(o.cargo, '${o.empresa} • ${o.ubicacion}', () => _abrirFormulario(laboral: o), () async {
                    await _ejecutar(() => _repo.eliminarLaboral(o.id), 'Oferta eliminada');
                  }),
              ]);
            },
          ),
      ],
    );
  }

  Widget _chip(String texto, int i) {
    final sel = _tipo == i;
    return InkWell(
      onTap: () => setState(() => _tipo = i),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: sel ? azulOscuro : const Color(0xFFF1F2F4),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(texto, style: TextStyle(fontSize: 12, color: sel ? Colors.white : Colors.black)),
      ),
    );
  }

  // Ejecuta una llamada a la API, muestra el resultado y refresca la lista.
  Future<void> _ejecutar(Future<bool> Function() accion, String exito) async {
    try {
      await accion();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(exito)));
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
    }
    _refrescar();
  }

  Widget _filaBorrable(String titulo, String sub, VoidCallback editar, Future<void> Function() borrar) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(titulo, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                if (sub.isNotEmpty)
                  Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11, color: grisTexto)),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Editar',
            onPressed: editar,
            icon: const Icon(Icons.edit_outlined, size: 20, color: azulOscuro),
          ),
          IconButton(
            tooltip: 'Eliminar',
            onPressed: () => _confirmarBorrar(borrar),
            icon: const Icon(Icons.delete_outline, size: 20, color: rojoCerrar),
          ),
        ],
      ),
    );
  }

  void _confirmarBorrar(Future<void> Function() borrar) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar'),
        content: const Text('¿Quieres quitar esta publicación?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              borrar();
            },
            child: const Text('Eliminar', style: TextStyle(color: rojoCerrar)),
          ),
        ],
      ),
    );
  }

  void _abrirFormulario({OfertaAcademica? academica, OfertaLaboral? laboral}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _tipo == 0
            ? _FormularioAcademico(onGuardado: _refrescar, existente: academica)
            : _FormularioLaboral(onGuardado: _refrescar, existente: laboral),
      ),
    );
  }
}

// Formulario de oportunidad académica
class _FormularioAcademico extends StatefulWidget {
  final VoidCallback onGuardado;
  final OfertaAcademica? existente; // si viene, el formulario edita (PUT) en vez de crear (POST)
  const _FormularioAcademico({required this.onGuardado, this.existente});

  @override
  State<_FormularioAcademico> createState() => _FormularioAcademicoState();
}

class _FormularioAcademicoState extends State<_FormularioAcademico> {
  final _formKey = GlobalKey<FormState>();
  final _repo = OportunidadRepositorio();

  final _nombre = TextEditingController();
  final _descripcion = TextEditingController();
  final _requisitos = TextEditingController();
  final _cupos = TextEditingController();

  @override
  void initState() {
    super.initState();
    final e = widget.existente;
    if (e != null) {
      _nombre.text = e.nombre;
      _descripcion.text = e.descripcion;
      _requisitos.text = e.requisitos;
      _cupos.text = '${e.cupos}';
    }
  }

  @override
  void dispose() {
    _nombre.dispose();
    _descripcion.dispose();
    _requisitos.dispose();
    _cupos.dispose();
    super.dispose();
  }

  Future<void> _guardar() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final oferta = OfertaAcademica(
      id: widget.existente?.id ?? 0,
      nombre: _nombre.text,
      descripcion: _descripcion.text,
      requisitos: _requisitos.text,
      cupos: int.tryParse(_cupos.text) ?? 0,
    );
    try {
      if (widget.existente == null) {
        await _repo.agregarAcademica(oferta);
      } else {
        await _repo.editarAcademica(oferta);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
      return;
    }
    if (!mounted) return;
    final editando = widget.existente != null;
    final mensajero = ScaffoldMessenger.of(context);
    Navigator.pop(context);
    widget.onGuardado();
    mensajero.showSnackBar(
      SnackBar(content: Text(editando ? 'Oportunidad actualizada' : 'Oportunidad publicada')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.existente == null ? 'Nueva oportunidad académica' : 'Editar oportunidad académica',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            CampoTexto(
              etiqueta: 'Nombre del curso *',
              ayuda: 'Ej: Desarrollo Web Frontend',
              control: _nombre,
              validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Descripción',
              ayuda: 'Ej: Beca 100% - Tecnológico de Bolívar',
              control: _descripcion,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Requisitos',
              ayuda: 'Ej: Ninguno',
              control: _requisitos,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Cupos disponibles',
              ayuda: 'Ej: 30',
              control: _cupos,
              teclado: TextInputType.number,
              validador: (v) {
                final t = (v ?? '').trim();
                if (t.isEmpty) return 'Obligatorio';
                if (int.tryParse(t) == null) return 'Solo números';
                return null;
              },
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancelar'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                      onPressed: _guardar,
                      child: Text(widget.existente == null ? 'Publicar' : 'Guardar cambios')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// Formulario de oferta laboral
class _FormularioLaboral extends StatefulWidget {
  final VoidCallback onGuardado;
  final OfertaLaboral? existente; // si viene, el formulario edita (PUT) en vez de crear (POST)
  const _FormularioLaboral({required this.onGuardado, this.existente});

  @override
  State<_FormularioLaboral> createState() => _FormularioLaboralState();
}

class _FormularioLaboralState extends State<_FormularioLaboral> {
  final _formKey = GlobalKey<FormState>();
  final _repo = OportunidadRepositorio();

  final _empresa = TextEditingController();
  final _cargo = TextEditingController();
  final _descripcion = TextEditingController();
  final _requisitos = TextEditingController();
  final _ubicacion = TextEditingController();
  final _salario = TextEditingController();
  final _contacto = TextEditingController();

  @override
  void initState() {
    super.initState();
    final e = widget.existente;
    if (e != null) {
      _empresa.text = e.empresa;
      _cargo.text = e.cargo;
      _descripcion.text = e.descripcion;
      _requisitos.text = e.requisitos;
      _ubicacion.text = e.ubicacion;
      _salario.text = e.salario;
      _contacto.text = e.contacto;
    }
  }

  @override
  void dispose() {
    for (final c in [_empresa, _cargo, _descripcion, _requisitos, _ubicacion, _salario, _contacto]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _guardar() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final oferta = OfertaLaboral(
      id: widget.existente?.id ?? 0,
      empresa: _empresa.text,
      cargo: _cargo.text,
      descripcion: _descripcion.text,
      requisitos: _requisitos.text,
      ubicacion: _ubicacion.text,
      salario: _salario.text,
      fechaPublicacion:
          widget.existente?.fechaPublicacion ?? DateTime.now().toIso8601String().substring(0, 10),
      contacto: _contacto.text,
    );
    try {
      if (widget.existente == null) {
        await _repo.agregarLaboral(oferta);
      } else {
        await _repo.editarLaboral(oferta);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
      return;
    }
    if (!mounted) return;
    final editando = widget.existente != null;
    final mensajero = ScaffoldMessenger.of(context);
    Navigator.pop(context);
    widget.onGuardado();
    mensajero.showSnackBar(
      SnackBar(content: Text(editando ? 'Oferta actualizada' : 'Oferta publicada')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.existente == null ? 'Nueva oferta laboral' : 'Editar oferta laboral',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            CampoTexto(
              etiqueta: 'Empresa *',
              ayuda: 'Ej: Bolívar Tech Solutions',
              control: _empresa,
              validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Cargo *',
              ayuda: 'Ej: Desarrollo Frontend Junior',
              control: _cargo,
              validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Descripción',
              ayuda: 'Ej: Mantenimiento de aplicaciones web',
              control: _descripcion,
              maxLineas: 3,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Requisitos',
              ayuda: 'Ej: HTML, CSS y JavaScript',
              control: _requisitos,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Ubicación',
              ayuda: 'Ej: Cartagena',
              control: _ubicacion,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Salario',
              ayuda: r'Ej: $1.5M - $1.8M COP',
              control: _salario,
            ),
            const SizedBox(height: 12),
            CampoTexto(
              etiqueta: 'Contacto',
              ayuda: 'Ej: empleo@empresa.co',
              control: _contacto,
              teclado: TextInputType.emailAddress,
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancelar'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                      onPressed: _guardar,
                      child: Text(widget.existente == null ? 'Publicar' : 'Guardar cambios')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Alertas ----------------

class _PestanaAlertas extends StatefulWidget {
  const _PestanaAlertas();

  @override
  State<_PestanaAlertas> createState() => _PestanaAlertasState();
}

class _PestanaAlertasState extends State<_PestanaAlertas> {
  final _repo = NotificacionRepositorio();
  final _repoUsuarios = UsuarioRepositorio();

  // Alerta para un usuario específico (0 = a todos)
  int _destino = 0;
  int _version = 0;

  final _titulo = TextEditingController();
  final _mensaje = TextEditingController();
  String _icono = 'notificacion';

  Future<List<Map<String, Object?>>>? _usuarios;
  int _cantUsuarios = 0;

  @override
  void initState() {
    super.initState();
    _cargarUsuarios();
  }

  Future<void> _cargarUsuarios() async {
    final filas = await _repoUsuarios.listar();
    if (mounted) {
      setState(() {
        _usuarios = Future.value(filas);
        _cantUsuarios = filas.length;
      });
    }
  }

  Future<void> _enviar() async {
    if (_titulo.text.trim().isEmpty || _mensaje.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa título y mensaje')),
      );
      return;
    }

    int enviadas;
    try {
      if (_destino == 0) {
        enviadas = await _repo.crearParaTodos(
          titulo: _titulo.text,
          mensaje: _mensaje.text,
          icono: _icono,
        );
      } else {
        final ok = await _repo.crear(
          usuarioId: _destino,
          titulo: _titulo.text,
          mensaje: _mensaje.text,
          icono: _icono,
        );
        enviadas = ok ? 1 : 0;
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
      return;
    }

    _titulo.clear();
    _mensaje.clear();
    setState(() => _version++);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Alerta enviada a $enviadas usuario(s)')),
    );
  }

  @override
  void dispose() {
    _titulo.dispose();
    _mensaje.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        const Text('Nueva alerta', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        CampoTexto(
          etiqueta: 'Título *',
          ayuda: 'Ej: Nueva beca disponible',
          control: _titulo,
        ),
        const SizedBox(height: 12),
        CampoTexto(
          etiqueta: 'Mensaje *',
          ayuda: 'Texto que verá el usuario',
          control: _mensaje,
          maxLineas: 3,
        ),
        const SizedBox(height: 12),
        const Text('Tipo de ícono', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            _chipIcono('General', 'notificacion', Icons.notifications),
            _chipIcono('Beca', 'beca', Icons.school),
            _chipIcono('Empleo', 'empleo', Icons.work),
            _chipIcono('Postulación', 'postulacion', Icons.description),
          ],
        ),
        const SizedBox(height: 14),
        FutureBuilder<List<Map<String, Object?>>>(
          future: _usuarios,
          builder: (c, s) {
            final lista = s.data ?? [];
            final opciones = [
              const DropdownMenuItem(value: 0, child: Text('Todos los usuarios')),
              for (final u in lista)
                DropdownMenuItem(
                  value: u['id'] as int,
                  child: Text('${u['nombre']} ${u['apellido']}'.trim()),
                ),
            ];
            return DropdownButtonFormField<int>(
              initialValue: _destino,
              items: opciones,
              onChanged: (v) => setState(() => _destino = v ?? 0),
              style: const TextStyle(fontSize: 14, color: Colors.black),
              decoration: const InputDecoration(
                labelText: 'Enviar a',
                labelStyle: TextStyle(fontSize: 13),
              ),
            );
          },
        ),
        const SizedBox(height: 8),
        Text('$_cantUsuarios usuario(s) registrados en total',
            style: const TextStyle(fontSize: 11, color: grisTexto)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _enviar,
          icon: const Icon(Icons.send, size: 16),
          label: const Text('Enviar alerta'),
        ),
        const SizedBox(height: 24),
        const Text('Alertas recientes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 10),
        _listaAlertas(),
      ],
    );
  }

  Widget _chipIcono(String texto, String clave, IconData icono) {
    final sel = _icono == clave;
    return InkWell(
      onTap: () => setState(() => _icono = clave),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: sel ? azulOscuro : const Color(0xFFF1F2F4),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icono, size: 14, color: sel ? Colors.black : azulOscuro),
            const SizedBox(width: 6),
            Text(texto, style: TextStyle(fontSize: 12, color: sel ? Colors.white : Colors.black)),
          ],
        ),
      ),
    );
  }

  Widget _listaAlertas() {
    return FutureBuilder<List<Notificacion>>(
      future: _notificacionesRecientes(),
      key: ValueKey('al$_version'),
      builder: (c, s) {
        if (!s.hasData) return const TextoVacio('Cargando...');
        if (s.data!.isEmpty) return const TextoVacio('Todavía no se han enviado alertas.');
        return Column(
          children: [
            for (final n in s.data!.take(10)) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(iconoNotificacion(n.icono), size: 18, color: azulOscuro),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(n.titulo,
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                          const SizedBox(height: 2),
                          Text(n.mensaje, style: const TextStyle(fontSize: 12, color: grisTexto)),
                          const SizedBox(height: 4),
                          Text(tiempoRelativo(n.fechaMillis),
                              style: const TextStyle(fontSize: 11, color: Color(0xFFB0B0B0))),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () async {
                        try {
                          await _repo.eliminar(n.id);
                        } on ApiException catch (e) {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
                        }
                        if (mounted) setState(() => _version++);
                      },
                      icon: const Icon(Icons.delete_outline, size: 18, color: rojoCerrar),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ],
        );
      },
    );
  }

  Future<List<Notificacion>> _notificacionesRecientes() async {
    return _repo.recientes(limite: 10);
  }
}
