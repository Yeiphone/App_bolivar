import 'package:flutter/material.dart';
import '../componentes.dart';
import '../datos/api_cliente.dart';
import '../datos/modelos.dart';
import '../datos/usuario_repositorio.dart';
import '../tema.dart';

class LoginPantalla extends StatefulWidget {
  final void Function(Usuario) onEntrar;
  final void Function() onCrearCuenta;

  const LoginPantalla({super.key, required this.onEntrar, required this.onCrearCuenta});

  @override
  State<LoginPantalla> createState() => _LoginPantallaState();
}

class _LoginPantallaState extends State<LoginPantalla> {
  final _formKey = GlobalKey<FormState>();
  final _correo = TextEditingController();
  final _clave = TextEditingController();
  final _repo = UsuarioRepositorio();

  bool _errorCredenciales = false;
  String? _errorConexion;
  bool _cargando = false;

  @override
  void dispose() {
    _correo.dispose();
    _clave.dispose();
    super.dispose();
  }

  Future<void> _entrar() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _cargando = true;
      _errorCredenciales = false;
      _errorConexion = null;
    });

    Usuario? usuario;
    try {
      usuario = await _repo.iniciarSesion(_correo.text, _clave.text);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _cargando = false;
        _errorConexion = e.mensaje;
      });
      return;
    }

    if (!mounted) return;
    setState(() => _cargando = false);

    if (usuario != null) {
      widget.onEntrar(usuario);
    } else {
      setState(() => _errorCredenciales = true);
    }
  }

  // Permite cambiar la dirección del servidor (necesario en un celular real).
  Future<void> _configurarServidor() async {
    final control = TextEditingController(text: ApiCliente.urlBase);
    final guardar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Servidor de la API'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: control,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(hintText: 'http://192.168.1.10:3000'),
            ),
            const SizedBox(height: 10),
            const Text(
              'Emulador de Android: http://10.0.2.2:3000\n'
              'Celular real: la IP de tu PC, ej. http://192.168.1.10:3000',
              style: TextStyle(fontSize: 11, color: grisTexto),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar')),
        ],
      ),
    );
    if (guardar == true) {
      await ApiCliente.guardarUrl(control.text);
      if (mounted) setState(() => _errorConexion = null);
    }
    control.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: IconButton(
                    tooltip: 'Servidor de la API',
                    onPressed: _configurarServidor,
                    icon: const Icon(Icons.settings, size: 20, color: grisTexto),
                  ),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      color: azulOscuro,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.school, color: Colors.white, size: 30),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Iniciar sesión',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Ingresa tus credenciales para acceder.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: grisTexto),
                ),
                const SizedBox(height: 24),
                if (_errorConexion != null)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF4E5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.wifi_off, color: Color(0xFFB26A00), size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _errorConexion!,
                            style: const TextStyle(color: Color(0xFFB26A00), fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (_errorCredenciales)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFDECEC),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.warning, color: Color(0xFFD32F2F), size: 18),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Correo o contraseña incorrectos',
                            style: TextStyle(color: Color(0xFFD32F2F), fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                CampoTexto(
                  etiqueta: 'Correo electrónico',
                  ayuda: 'ejemplo@correo.com',
                  control: _correo,
                  teclado: TextInputType.emailAddress,
                  validador: (v) {
                    final t = (v ?? '').trim();
                    if (t.isEmpty) return 'Este campo es obligatorio';
                    if (!t.contains('@') || !t.contains('.')) return 'Correo no válido';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                CampoTexto(
                  etiqueta: 'Contraseña',
                  ayuda: 'Tu contraseña',
                  control: _clave,
                  obscure: true,
                  validador: (v) => (v ?? '').trim().isEmpty ? 'Este campo es obligatorio' : null,
                ),
                const SizedBox(height: 10),
                const Text(
                  '¿Olvidaste tu contraseña? Contacta al administrador.',
                  style: TextStyle(fontSize: 12, color: azulOscuro),
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _cargando ? null : _entrar,
                  child: _cargando
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Iniciar sesión'),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('¿No tienes una cuenta? ', style: TextStyle(fontSize: 13, color: grisTexto)),
                    GestureDetector(
                      onTap: widget.onCrearCuenta,
                      child: const Text(
                        'Crear cuenta',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: azulOscuro),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: grisFondo,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Cuenta de prueba: admin@bolivar.com / admin123',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: grisTexto),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
