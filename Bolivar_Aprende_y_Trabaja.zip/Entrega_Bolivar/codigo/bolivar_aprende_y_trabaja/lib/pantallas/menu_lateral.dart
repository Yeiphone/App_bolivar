import 'dart:io';

import 'package:flutter/material.dart';
import '../tema.dart';

class OpcionMenu {
  final String id;
  final IconData icono;
  final String texto;
  const OpcionMenu(this.id, this.icono, this.texto);
}

const opcionesPrincipales = [
  OpcionMenu('inicio', Icons.home, 'Inicio'),
  OpcionMenu('explorar', Icons.explore, 'Explorar'),
  OpcionMenu('academicas', Icons.school, 'Oportunidades Académicas'),
  OpcionMenu('laborales', Icons.work, 'Ofertas Laborales'),
  OpcionMenu('becas', Icons.workspace_premium, 'Becas y Ayudas'),
  OpcionMenu('eventos', Icons.event, 'Eventos y Talleres'),
  OpcionMenu('cursos', Icons.menu_book, 'Mis Cursos'),
  OpcionMenu('postulaciones', Icons.description, 'Mis Postulaciones'),
  OpcionMenu('recomendadas', Icons.auto_awesome, 'Recomendadas para Ti'),
];

// El administrador no ve secciones de estudiantes (cursos, becas, postulaciones
// propias...): administra datos y revisa postulaciones de los demás.
const opcionesAdministrador = [
  OpcionMenu('inicio', Icons.home, 'Inicio'),
  OpcionMenu('gestion', Icons.folder_shared, 'Gestión de datos'),
  OpcionMenu('recibidas', Icons.mark_email_read, 'Postulaciones recibidas'),
];

const opcionesInferiores = [
  OpcionMenu('perfil', Icons.person, 'Mi Perfil'),
  OpcionMenu('exportar', Icons.upload, 'Exportar mis datos'),
  OpcionMenu('configuracion', Icons.settings, 'Configuración'),
];

// Menú lateral (drawer). La app lo abre desde el ícono de hamburguesa en Inicio.
class MenuLateral extends StatelessWidget {
  final String nombre;
  final String correo;
  final bool esAdmin;
  final String? fotoRuta;
  final String seleccion;
  final void Function(String) onOpcion;
  final VoidCallback onCerrar;
  final VoidCallback onCerrarSesion;

  const MenuLateral({
    super.key,
    required this.nombre,
    required this.correo,
    required this.esAdmin,
    this.fotoRuta,
    required this.seleccion,
    required this.onOpcion,
    required this.onCerrar,
    required this.onCerrarSesion,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.of(context).size.width * 0.84,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            color: moradoMenu,
            padding: const EdgeInsets.fromLTRB(20, 44, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: const Color(0xFFCFCFCF),
                      backgroundImage:
                          fotoRuta != null && File(fotoRuta!).existsSync() ? FileImage(File(fotoRuta!)) : null,
                      child: fotoRuta != null && File(fotoRuta!).existsSync()
                          ? null
                          : const Icon(Icons.person, color: Color(0xFF757575), size: 30),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: onCerrar,
                      icon: const Icon(Icons.close, color: Colors.white, size: 20),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  nombre,
                  style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold),
                ),
                Text(
                  correo,
                  style: const TextStyle(color: Color(0xFFC9C4D8), fontSize: 12),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: amarilloBadge,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    esAdmin ? 'ADMINISTRADOR' : 'ESTUDIANTE',
                    style: const TextStyle(
                      color: moradoMenu,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                for (final o in (esAdmin ? opcionesAdministrador : opcionesPrincipales))
                  _FilaMenu(o, seleccion == o.id, onOpcion),
                const SizedBox(height: 8),
                const Divider(color: grisBorde, height: 1),
                const SizedBox(height: 8),
                for (final o in opcionesInferiores)
                  _FilaMenu(o, seleccion == o.id, onOpcion),
                _FilaMenu(
                  const OpcionMenu('cerrar_sesion', Icons.exit_to_app, 'Cerrar Sesión'),
                  false,
                  (_) => onCerrarSesion(),
                  color: rojoCerrar,
                ),
              ],
            ),
          ),
          const Divider(color: grisBorde, height: 1),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 14, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Bolívar Aprende y Trabaja',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                SizedBox(height: 2),
                Text('Versión 1.0.0', style: TextStyle(fontSize: 11, color: grisTexto)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilaMenu extends StatelessWidget {
  final OpcionMenu opcion;
  final bool activo;
  final void Function(String) onTap;
  final Color? color;

  const _FilaMenu(this.opcion, this.activo, this.onTap, {this.color});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: activo ? lilaSeleccion : Colors.transparent,
      child: InkWell(
        onTap: () => onTap(opcion.id),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          child: Row(
            children: [
              Container(
                width: 4,
                height: 20,
                decoration: BoxDecoration(
                  color: activo ? naranjaAcento : Colors.transparent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              Icon(opcion.icono, size: 18, color: color ?? Colors.black),
              const SizedBox(width: 14),
              Text(
                opcion.texto,
                style: TextStyle(
                  fontSize: 14,
                  color: color ?? Colors.black,
                  fontWeight: activo ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
