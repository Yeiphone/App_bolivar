import 'package:flutter/material.dart';
import '../componentes.dart';
import '../datos/api_cliente.dart';
import '../datos/usuario_repositorio.dart';

class RegistroPantalla extends StatefulWidget {
  final void Function() onRegistrado;

  const RegistroPantalla({super.key, required this.onRegistrado});

  @override
  State<RegistroPantalla> createState() => _RegistroPantallaState();
}

class _RegistroPantallaState extends State<RegistroPantalla> {
  final _formKey = GlobalKey<FormState>();
  final _repo = UsuarioRepositorio();

  final _nombre = TextEditingController();
  final _apellido = TextEditingController();
  final _identificacion = TextEditingController();
  final _correo = TextEditingController();
  final _telefono = TextEditingController();
  final _municipio = TextEditingController();
  final _clave = TextEditingController();
  final _clave2 = TextEditingController();

  String _tipoPerfil = 'Estudiante';
  bool _cargando = false;
  String? _mensajeError;

  @override
  void dispose() {
    for (final c in [_nombre, _apellido, _identificacion, _correo, _telefono, _municipio, _clave, _clave2]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _guardar() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _cargando = true;
      _mensajeError = null;
    });

    bool ok;
    try {
      ok = await _repo.registrar(
        nombre: _nombre.text,
        apellido: _apellido.text,
        identificacion: _identificacion.text,
        correo: _correo.text,
        telefono: _telefono.text,
        municipio: _municipio.text,
        password: _clave.text,
        tipoPerfil: _tipoPerfil,
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _cargando = false;
        _mensajeError = e.mensaje;
      });
      return;
    }

    if (!mounted) return;
    setState(() => _cargando = false);

    if (ok) {
      widget.onRegistrado();
    } else {
      setState(() => _mensajeError = 'Ya existe una cuenta con ese correo');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Crear cuenta', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_mensajeError != null)
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFDECEC),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      _mensajeError!,
                      style: const TextStyle(color: Color(0xFFD32F2F), fontSize: 13),
                    ),
                  ),
                CampoTexto(
                  etiqueta: 'Nombre',
                  ayuda: 'Tu nombre',
                  control: _nombre,
                  validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Apellido',
                  ayuda: 'Tu apellido',
                  control: _apellido,
                  validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Identificación',
                  ayuda: 'Cédula o documento',
                  control: _identificacion,
                  teclado: TextInputType.number,
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Correo electrónico',
                  ayuda: 'ejemplo@correo.com',
                  control: _correo,
                  teclado: TextInputType.emailAddress,
                  validador: (v) {
                    final t = (v ?? '').trim();
                    if (t.isEmpty) return 'Obligatorio';
                    if (!t.contains('@') || !t.contains('.')) return 'Correo no válido';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Teléfono',
                  ayuda: 'Opcional',
                  control: _telefono,
                  teclado: TextInputType.phone,
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Municipio',
                  ayuda: 'Ej: Cartagena',
                  control: _municipio,
                  validador: (v) => (v ?? '').trim().isEmpty ? 'Obligatorio' : null,
                ),
                const SizedBox(height: 12),
                const Text('Perfil', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  initialValue: _tipoPerfil,
                  items: const [
                    DropdownMenuItem(value: 'Estudiante', child: Text('Estudiante')),
                    DropdownMenuItem(value: 'Profesional', child: Text('Profesional')),
                    DropdownMenuItem(value: 'Emprendedor', child: Text('Emprendedor')),
                  ],
                  onChanged: (v) => setState(() => _tipoPerfil = v ?? 'Estudiante'),
                  style: const TextStyle(fontSize: 14, color: Colors.black),
                  decoration: const InputDecoration(hintText: 'Selecciona tu perfil'),
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Contraseña',
                  ayuda: 'Mínimo 6 caracteres',
                  control: _clave,
                  obscure: true,
                  validador: (v) {
                    final t = (v ?? '').trim();
                    if (t.isEmpty) return 'Obligatorio';
                    if (t.length < 6) return 'Mínimo 6 caracteres';
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                CampoTexto(
                  etiqueta: 'Confirmar contraseña',
                  ayuda: 'Repite tu contraseña',
                  control: _clave2,
                  obscure: true,
                  validador: (v) {
                    if ((v ?? '').trim() != _clave.text.trim()) return 'Las contraseñas no coinciden';
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _cargando ? null : _guardar,
                  child: _cargando
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Crear cuenta'),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
