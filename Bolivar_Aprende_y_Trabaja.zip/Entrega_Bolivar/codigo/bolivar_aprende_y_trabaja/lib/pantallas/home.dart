import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../componentes.dart';
import '../datos/api_cliente.dart';
import '../datos/foto_perfil.dart';
import '../datos/inscripcion_repositorio.dart';
import '../datos/modelos.dart';
import '../datos/notificacion_repositorio.dart';
import '../datos/oportunidad_repositorio.dart';
import '../datos/postulacion_repositorio.dart';
import '../datos/usuario_repositorio.dart';
import '../tema.dart';
import 'gestion_datos.dart';
import 'menu_lateral.dart';

// Pantalla principal: menú lateral, barra inferior y todas las secciones.
class HomePantalla extends StatefulWidget {
  final Usuario usuario;
  final void Function() onCerrarSesion;

  const HomePantalla({super.key, required this.usuario, required this.onCerrarSesion});

  @override
  State<HomePantalla> createState() => _HomePantallaState();
}

class _HomePantallaState extends State<HomePantalla> {
  final _oportunidades = OportunidadRepositorio();
  final _postulaciones = PostulacionRepositorio();
  final _notificaciones = NotificacionRepositorio();
  final _inscripciones = InscripcionRepositorio();
  final _usuarios = UsuarioRepositorio();
  final _prefsConfig = _PreferenciasConfig();

  String _pestana = 'inicio';
  String? _seccion;
  int _version = 0;
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _soloMiMunicipio = false;
  bool _notificacionesActivas = true;
  String? _fotoRuta;

  late Future<List<OfertaAcademica>> _academicas;
  late Future<List<OfertaLaboral>> _laborales;
  late Future<List<Postulacion>> _misPostulaciones;
  late Future<List<Notificacion>> _misNotificaciones;
  late Future<Set<int>> _idsInscritos;
  late Future<List<OfertaAcademica>> _misInscripciones;
  late Future<List<PostulacionRecibida>> _recibidas;
  late Future<int> _totalUsuarios;

  @override
  void initState() {
    super.initState();
    _cargarTodo();
    _prefsConfig.cargar().then((_) {
      setState(() {
        _soloMiMunicipio = _prefsConfig.soloMunicipio;
        _notificacionesActivas = _prefsConfig.notificaciones;
      });
    });
    FotoPerfil.ruta(widget.usuario.id).then((r) {
      if (mounted) setState(() => _fotoRuta = r);
    });
  }

  void _cargarTodo() {
    final id = widget.usuario.id;
    setState(() {
      _academicas = _oportunidades.academicas();
      _laborales = _oportunidades.laborales();
      _misPostulaciones = _postulaciones.listarPorUsuario(id);
      _misNotificaciones = _notificaciones.listarPorUsuario(id);
      _idsInscritos = _inscripciones.idsInscritos(id);
      _misInscripciones = _inscripciones.misInscripciones(id);
      _recibidas = _postulaciones.todas();
      _totalUsuarios = _usuarios.contar();
    });
  }

  void _refrescar() {
    setState(() => _version++);
    _cargarTodo();
  }

  // Acciones del menú lateral
  void _tocarOpcion(String id) {
    Navigator.pop(context); // primero se cierra el drawer: si se hace después,
    // pop cerraría la pantalla o diálogo recién abierto
    switch (id) {
      case 'inicio':
        setState(() {
          _pestana = 'inicio';
          _seccion = null;
        });
        break;
      case 'explorar':
        setState(() {
          _pestana = 'explorar';
          _seccion = null;
        });
        break;
      case 'cursos':
        setState(() {
          _pestana = 'cursos';
          _seccion = null;
        });
        break;
      case 'perfil':
        setState(() {
          _pestana = 'perfil';
          _seccion = null;
        });
        break;
      case 'academicas':
      case 'laborales':
      case 'becas':
      case 'eventos':
      case 'recomendadas':
      case 'configuracion':
        setState(() => _seccion = id);
        break;
      case 'recibidas':
        setState(() {
          _pestana = 'recibidas';
          _seccion = null;
        });
        break;
      case 'gestion':
        _abrirGestion();
        break;
      case 'postulaciones':
        _mostrarPostulaciones();
        break;
      case 'exportar':
        _exportarDatos();
        break;
      case 'cerrar_sesion':
        _confirmarCerrarSesion();
        break;
    }
  }

  Future<void> _abrirGestion() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const GestionDatosPantalla()),
    );
    _refrescar();
  }

  void _avisarError(ApiException e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.mensaje)));
  }

  // Inscripción a un curso/beca/evento (lado del estudiante).
  Future<void> _inscribirse(int ofertaId) async {
    bool ok;
    try {
      ok = await _inscripciones.inscribirse(widget.usuario.id, ofertaId);
    } on ApiException catch (e) {
      _avisarError(e);
      return;
    }
    if (!mounted) return;
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Inscripción registrada')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ya estabas inscrito en esa oferta')),
      );
    }
    _refrescar();
  }

  // Postulación a una oferta laboral (lado del estudiante).
  Future<void> _postularA(int ofertaId) async {
    bool ok;
    try {
      ok = await _postulaciones.postularse(widget.usuario.id, ofertaId);
    } on ApiException catch (e) {
      _avisarError(e);
      return;
    }
    if (!mounted) return;
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Postulación enviada')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ya te habías postulado en esa oferta')),
      );
    }
    _refrescar();
  }

  Future<void> _anularInscripcion(int ofertaId) async {
    await _inscripciones.anular(widget.usuario.id, ofertaId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Inscripción anulada')),
    );
    _refrescar();
  }

  // Cambio de estado de una postulación recibida (solo admin).
  Future<void> _cambiarEstadoPostulacion(int postulacionId, String estado) async {
    await _postulaciones.cambiarEstado(postulacionId, estado);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Postulación marcada como ${estado.toLowerCase()}')),
    );
    _refrescar();
  }

  Future<void> _cambiarFoto() async {
    final ruta = await FotoPerfil.cambiar(widget.usuario.id);
    if (mounted) setState(() => _fotoRuta = ruta);
  }

  Future<void> _mostrarNotificaciones() async {
    final lista = await _misNotificaciones;
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => _PanelNotificaciones(
        notificaciones: lista,
        onCerrar: () {
          _notificaciones.marcarTodasComoLeidas(widget.usuario.id);
          Navigator.pop(context);
          _refrescar();
        },
      ),
    );
  }

  void _mostrarPostulaciones() {
    _misPostulaciones.then((lista) {
      if (!mounted) return;
      showDialog(context: context, builder: (_) => _PanelPostulaciones(lista: lista));
    });
  }

  void _exportarDatos() {
    _misPostulaciones.then((post) {
      _misNotificaciones.then((noti) {
        if (!mounted) return;
        final texto = StringBuffer()
          ..writeln('Bolívar Aprende y Trabaja - Mis datos')
          ..writeln('Usuario: ${widget.usuario.nombreCompleto}')
          ..writeln('Correo: ${widget.usuario.correo}')
          ..writeln('Municipio: ${widget.usuario.municipio}')
          ..writeln('')
          ..writeln('Postulaciones (${post.length}):');
        for (final p in post) {
          texto.writeln('  - ${p.cargo} en ${p.empresa} (${p.estado})');
        }
        texto.writeln('');
        texto.writeln('Notificaciones (${noti.length}):');
        for (final n in noti) {
          texto.writeln('  - ${n.titulo}: ${n.mensaje}');
        }
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Exportar mis datos'),
            content: SingleChildScrollView(child: Text(texto.toString(), style: const TextStyle(fontSize: 12))),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
            ],
          ),
        );
      });
    });
  }

  void _confirmarCerrarSesion() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cerrar sesión'),
        content: const Text('¿Seguro que quieres cerrar tu sesión?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              widget.onCerrarSesion();
            },
            child: const Text('Cerrar sesión', style: TextStyle(color: rojoCerrar)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final esAdmin = widget.usuario.esAdministrador;
    // El estudiante tiene sus secciones de búsqueda de oportunidades;
    // el administrador ve su panel de postulaciones recibidas.
    final tabs = esAdmin
        ? const ['inicio', 'recibidas', 'perfil']
        : const ['inicio', 'explorar', 'cursos', 'perfil'];
    final itemSeleccionado = _seccion ?? _pestana;

    return Scaffold(
      key: _scaffoldKey,
      drawer: MenuLateral(
        nombre: widget.usuario.nombreCompleto,
        correo: widget.usuario.correo,
        esAdmin: esAdmin,
        fotoRuta: _fotoRuta,
        seleccion: itemSeleccionado,
        onOpcion: _tocarOpcion,
        onCerrar: () => Navigator.pop(context),
        onCerrarSesion: _confirmarCerrarSesion,
      ),
      bottomNavigationBar: _seccion == null
          ? NavigationBar(
              selectedIndex: tabs.contains(_pestana) ? tabs.indexOf(_pestana) : 0,
              onDestinationSelected: (i) {
                setState(() {
                  _pestana = tabs[i];
                  _seccion = null;
                });
                // El panel del admin se recarga para ver postulaciones nuevas.
                if (esAdmin) _refrescar();
              },
              destinations: esAdmin
                  ? const [
                      NavigationDestination(icon: Icon(Icons.home), label: 'Inicio'),
                      NavigationDestination(icon: Icon(Icons.mark_email_read), label: 'Postulaciones'),
                      NavigationDestination(icon: Icon(Icons.person), label: 'Perfil'),
                    ]
                  : const [
                      NavigationDestination(icon: Icon(Icons.home), label: 'Inicio'),
                      NavigationDestination(icon: Icon(Icons.search), label: 'Explorar'),
                      NavigationDestination(icon: Icon(Icons.menu_book), label: 'Mis cursos'),
                      NavigationDestination(icon: Icon(Icons.person), label: 'Perfil'),
                    ],
            )
          : null,
      body: SafeArea(
        child: _seccion != null
            ? _construirSeccion(_seccion!)
            : IndexedStack(
                index: tabs.contains(_pestana) ? tabs.indexOf(_pestana) : 0,
                children: esAdmin
                    ? [
                        _InicioAdmin(
                          usuario: widget.usuario,
                          academicas: _academicas,
                          laborales: _laborales,
                          recibidas: _recibidas,
                          totalUsuarios: _totalUsuarios,
                          onMenu: () => _scaffoldKey.currentState?.openDrawer(),
                          onNotificaciones: _mostrarNotificaciones,
                          onGestion: _abrirGestion,
                          onAlerta: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => const GestionDatosPantalla(pestanaInicial: 1)),
                            );
                            _refrescar();
                          },
                          onVerRecibidas: () => setState(() => _pestana = 'recibidas'),
                          onCambiarEstado: _cambiarEstadoPostulacion,
                          version: _version,
                        ),
                        _PostulacionesRecibidas(
                          recibidas: _recibidas,
                          onCambiarEstado: _cambiarEstadoPostulacion,
                          version: _version,
                        ),
                        _Perfil(
                          usuario: widget.usuario,
                          fotoRuta: _fotoRuta,
                          onCambiarFoto: _cambiarFoto,
                          onCerrarSesion: _confirmarCerrarSesion,
                        ),
                      ]
                    : [
                        _Inicio(
                          usuario: widget.usuario,
                          academicas: _academicas,
                          laborales: _laborales,
                          postulaciones: _misPostulaciones,
                          inscritos: _idsInscritos,
                          soloMiMunicipio: _soloMiMunicipio,
                          fotoRuta: _fotoRuta,
                          onMenu: () => _scaffoldKey.currentState?.openDrawer(),
                          onNotificaciones: _mostrarNotificaciones,
                          onCategoria: (id) => setState(() => _seccion = id),
                          onVerTodo: (id) => setState(() => _seccion = id),
                          onBuscar: () => setState(() {
                            _pestana = 'explorar';
                            _seccion = null;
                          }),
                          onInscribirse: _inscribirse,
                          onPostularse: _postularA,
                          version: _version,
                        ),
                        _Explorar(
                          academicas: _academicas,
                          laborales: _laborales,
                          postulaciones: _misPostulaciones,
                          inscritos: _idsInscritos,
                          soloMiMunicipio: _soloMiMunicipio,
                          usuario: widget.usuario,
                          onInscribirse: _inscribirse,
                          onPostularse: _postularA,
                          version: _version,
                        ),
                        _MisCursos(
                          inscripciones: _misInscripciones,
                          onAnular: _anularInscripcion,
                          onExplorar: () => setState(() => _seccion = 'academicas'),
                          version: _version,
                        ),
                        _Perfil(
                          usuario: widget.usuario,
                          fotoRuta: _fotoRuta,
                          onCambiarFoto: _cambiarFoto,
                          onCerrarSesion: _confirmarCerrarSesion,
                        ),
                      ],
              ),
      ),
    );
  }

  Widget _construirSeccion(String id) {
    void volver() => setState(() => _seccion = null);
    switch (id) {
      case 'academicas':
        return _SeccionAcademica(
          titulo: 'Oportunidades Académicas',
          onVolver: volver,
          future: _academicas,
          inscritos: _idsInscritos,
          onInscribirse: _inscribirse,
        );
      case 'laborales':
        return _SeccionOfertas(
          titulo: 'Ofertas Laborales',
          onVolver: volver,
          future: _laborales,
          postulaciones: _misPostulaciones,
          usuario: widget.usuario,
          soloMiMunicipio: _soloMiMunicipio,
          aviso: _soloMiMunicipio
              ? 'Filtrando por tu municipio: ${widget.usuario.municipio} (lo cambias en Configuración).'
              : null,
          onPostularse: _postularA,
        );
      case 'becas':
        return _SeccionAcademica(
          titulo: 'Becas y Ayudas',
          onVolver: volver,
          future: _academicas,
          inscritos: _idsInscritos,
          onInscribirse: _inscribirse,
          filtrar: (lista) => lista
              .where((o) =>
                  o.nombre.toLowerCase().contains('beca') ||
                  o.descripcion.toLowerCase().contains('beca') ||
                  o.nombre.toLowerCase().contains('gratuito') ||
                  o.descripcion.toLowerCase().contains('gratuito'))
              .toList(),
          vacio: 'No hay becas publicadas por ahora. Cuando se publique una, aparecerá aquí.',
        );
      case 'eventos':
        return _SeccionAcademica(
          titulo: 'Eventos y Talleres',
          onVolver: volver,
          future: _academicas,
          inscritos: _idsInscritos,
          onInscribirse: _inscribirse,
          filtrar: (lista) => lista
              .where((o) => const ['taller', 'evento', 'jornada', 'seminario', 'conferencia', 'capacitación']
                  .any((p) =>
                      o.nombre.toLowerCase().contains(p) || o.descripcion.toLowerCase().contains(p)))
              .toList(),
          vacio: 'No hay eventos ni talleres publicados en este momento.',
        );
      case 'recomendadas':
        return _SeccionOfertas(
          titulo: 'Recomendadas para Ti',
          onVolver: volver,
          future: _laborales,
          postulaciones: _misPostulaciones,
          usuario: widget.usuario,
          soloMiMunicipio: _soloMiMunicipio,
          recomendadas: true,
          onPostularse: _postularA,
        );
      case 'configuracion':
        return _Configuracion(
          onVolver: volver,
          soloMiMunicipio: _soloMiMunicipio,
          notificacionesActivas: _notificacionesActivas,
          onSoloMunicipio: (v) {
            setState(() => _soloMiMunicipio = v);
            _prefsConfig.guardarSoloMunicipio(v);
          },
          onNotificaciones: (v) {
            setState(() => _notificacionesActivas = v);
            _prefsConfig.guardarNotificaciones(v);
          },
          onCerrarSesion: _confirmarCerrarSesion,
        );
      default:
        return const SizedBox.shrink();
    }
  }
}

// ===================== INICIO =====================

class _Inicio extends StatelessWidget {
  final Usuario usuario;
  final Future<List<OfertaAcademica>> academicas;
  final Future<List<OfertaLaboral>> laborales;
  final Future<List<Postulacion>> postulaciones;
  final Future<Set<int>> inscritos;
  final bool soloMiMunicipio;
  final String? fotoRuta;
  final VoidCallback onMenu;
  final VoidCallback onNotificaciones;
  final void Function(String) onCategoria;
  final void Function(String) onVerTodo;
  final VoidCallback onBuscar;
  final Future<void> Function(int) onInscribirse;
  final Future<void> Function(int) onPostularse;
  final int version;

  const _Inicio({
    required this.usuario,
    required this.academicas,
    required this.laborales,
    required this.postulaciones,
    required this.inscritos,
    required this.soloMiMunicipio,
    this.fotoRuta,
    required this.onMenu,
    required this.onNotificaciones,
    required this.onCategoria,
    required this.onVerTodo,
    required this.onBuscar,
    required this.onInscribirse,
    required this.onPostularse,
    required this.version,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        IconButton(
          onPressed: onMenu,
          icon: const Icon(Icons.menu),
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _AvatarFoto(ruta: fotoRuta, radio: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hola, ${usuario.nombre}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text(usuario.municipio, style: const TextStyle(fontSize: 12, color: grisTexto)),
                ],
              ),
            ),
            InkWell(
              onTap: onNotificaciones,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(color: Color(0xFFF1F2F4), shape: BoxShape.circle),
                child: const Icon(Icons.notifications, color: azulOscuro, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        // Al tocarlo abre la pestaña Explorar, donde está la búsqueda real.
        TextField(
          readOnly: true,
          showCursor: false,
          onTap: onBuscar,
          decoration: const InputDecoration(
            hintText: 'Buscar cursos, empleos...',
            prefixIcon: Icon(Icons.search),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _Categoria(Icons.menu_book, 'Cursos', () => onCategoria('academicas')),
            _Categoria(Icons.work, 'Empleos', () => onCategoria('laborales')),
            _Categoria(Icons.workspace_premium, 'Becas', () => onCategoria('becas')),
            _Categoria(Icons.event, 'Eventos', () => onCategoria('eventos')),
          ],
        ),
        const SizedBox(height: 24),
        _tituloSeccion('Oportunidades académicas', () => onVerTodo('academicas')),
        const SizedBox(height: 10),
        FutureBuilder<List<OfertaAcademica>>(
          future: academicas,
          key: ValueKey('a$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            if (s.data!.isEmpty) return const TextoVacio('Todavía no hay oportunidades académicas publicadas.');
            return FutureBuilder<Set<int>>(
              future: inscritos,
              builder: (c2, s2) {
                final ids = s2.data ?? <int>{};
                return SizedBox(
                  height: 210,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final o in s.data!)
                        _TarjetaAcademica(
                          item: o,
                          inscrito: ids.contains(o.id),
                          onInscribirse: () => onInscribirse(o.id),
                        ),
                    ],
                  ),
                );
              },
            );
          },
        ),
        const SizedBox(height: 24),
        _tituloSeccion('Ofertas laborales', () => onVerTodo('laborales')),
        const SizedBox(height: 10),
        FutureBuilder<List<OfertaLaboral>>(
          future: laborales,
          key: ValueKey('l$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            if (s.data!.isEmpty) return const TextoVacio('Todavía no hay ofertas laborales publicadas.');
            return _listaLaborales(s.data!, postulaciones, onPostularse: onPostularse);
          },
        ),
        const SizedBox(height: 14),
        _tituloSeccion('Recomendadas para ti', () => onVerTodo('recomendadas')),
        const SizedBox(height: 10),
        FutureBuilder<List<OfertaLaboral>>(
          future: laborales,
          key: ValueKey('r$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            final todas = s.data!;
            if (todas.isEmpty) return const TextoVacio('Aún no tenemos recomendaciones para ti.');
            final mias = todas
                .where((o) => o.ubicacion.toLowerCase().contains(usuario.municipio.toLowerCase()))
                .toList();
            final lista = soloMiMunicipio ? mias : (mias.isEmpty ? todas : mias).take(2).toList();
            if (lista.isEmpty) return const TextoVacio('Aún no tenemos recomendaciones para ti.');
            return _listaLaborales(lista, postulaciones, onPostularse: onPostularse);
          },
        ),
      ],
    );
  }

  Widget _tituloSeccion(String t, VoidCallback ver) => InkWell(
        onTap: ver,
        borderRadius: BorderRadius.circular(6),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const Text('Ver todo', style: TextStyle(fontSize: 12, color: azulOscuro)),
            ],
          ),
        ),
      );
}

// Avatar con la foto de perfil del usuario (o el ícono si no tiene).
class _AvatarFoto extends StatelessWidget {
  final String? ruta;
  final double radio;
  const _AvatarFoto({required this.ruta, required this.radio});

  @override
  Widget build(BuildContext context) {
    final tieneFoto = ruta != null && File(ruta!).existsSync();
    return CircleAvatar(
      radius: radio,
      backgroundColor: const Color(0xFFE0E0E0),
      backgroundImage: tieneFoto ? FileImage(File(ruta!)) : null,
      child: tieneFoto ? null : Icon(Icons.person, size: radio, color: grisTexto),
    );
  }
}

class _Categoria extends StatelessWidget {
  final IconData icono;
  final String nombre;
  final VoidCallback onTap;
  const _Categoria(this.icono, this.nombre, this.onTap);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Column(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: const Color(0xFFE7ECF4),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icono, color: azulOscuro),
          ),
          const SizedBox(height: 6),
          Text(nombre, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

// Listado de ofertas laborales. Si onPostularse es null (por ejemplo en el
// panel del admin) no se muestra el botón.
Widget _listaLaborales(
  List<OfertaLaboral> lista,
  Future<List<Postulacion>> postulaciones, {
  required Future<void> Function(int)? onPostularse,
}) {
  return FutureBuilder<List<Postulacion>>(
    future: postulaciones,
    builder: (c, s) {
      final ids = s.data?.map((p) => p.ofertaId).toSet() ?? {};
      return Column(
        children: [
          for (final o in lista) ...[
            _FilaLaboral(
              oferta: o,
              yaPostulado: ids.contains(o.id),
              onPostularse: onPostularse != null ? () => onPostularse(o.id) : null,
            ),
            const SizedBox(height: 10),
          ],
        ],
      );
    },
  );
}

class _TarjetaAcademica extends StatelessWidget {
  final OfertaAcademica item;
  final bool inscrito;
  final VoidCallback onInscribirse;
  const _TarjetaAcademica({required this.item, required this.inscrito, required this.onInscribirse});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: grisFondo,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 76,
            decoration: const BoxDecoration(
              color: azulOscuro,
              borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Align(
              alignment: Alignment.topLeft,
              child: Container(
                margin: const EdgeInsets.all(8),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: naranjaAcento,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  item.cupos > 0 ? '${item.cupos} cupos' : 'Sin cupos',
                  style: const TextStyle(color: Colors.white, fontSize: 10),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.nombre,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 3),
                Text(item.descripcion,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: grisTexto)),
              ],
            ),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
            child: inscrito
                ? const Row(
                    children: [
                      Icon(Icons.check, size: 13, color: verdeOk),
                      SizedBox(width: 4),
                      Text('Inscrito',
                          style: TextStyle(fontSize: 11, color: verdeOk, fontWeight: FontWeight.w500)),
                    ],
                  )
                : InkWell(
                    onTap: onInscribirse,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: naranjaAcento,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text('Inscribirme',
                          style: TextStyle(fontSize: 11, color: Colors.white)),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilaLaboral extends StatelessWidget {
  final OfertaLaboral oferta;
  final bool yaPostulado;
  final VoidCallback? onPostularse;

  const _FilaLaboral({required this.oferta, required this.yaPostulado, required this.onPostularse});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: grisFondo,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFE3E7ED),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.work, color: azulOscuro),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(oferta.cargo, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text('${oferta.empresa} • ${oferta.ubicacion}',
                    style: const TextStyle(fontSize: 11, color: grisTexto)),
                if (oferta.salario.isNotEmpty)
                  Text(oferta.salario,
                      style: const TextStyle(fontSize: 11, color: azulOscuro, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (yaPostulado)
            const Row(
              children: [
                Icon(Icons.check, size: 14, color: verdeOk),
                SizedBox(width: 4),
                Text('Postulado',
                    style: TextStyle(fontSize: 11, color: verdeOk, fontWeight: FontWeight.w500)),
              ],
            )
          else if (onPostularse != null)
            InkWell(
              onTap: onPostularse,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: azulOscuro,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('Postularme', style: TextStyle(fontSize: 11, color: Colors.white)),
              ),
            ),
        ],
      ),
    );
  }
}

class _FilaAcademica extends StatelessWidget {
  final OfertaAcademica item;
  final bool inscrito;
  final VoidCallback? onInscribirse;
  final VoidCallback? onAnular;
  const _FilaAcademica({required this.item, this.inscrito = false, this.onInscribirse, this.onAnular});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFE3E7ED),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.school, color: azulOscuro),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.nombre, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text(item.descripcion,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: grisTexto)),
                if (item.cupos > 0)
                  Text('${item.cupos} cupos disponibles',
                      style: const TextStyle(fontSize: 11, color: azulOscuro, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (onAnular != null)
            InkWell(
              onTap: onAnular,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFFDECEA),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('Anular',
                    style: TextStyle(fontSize: 11, color: rojoCerrar, fontWeight: FontWeight.w500)),
              ),
            )
          else if (onInscribirse != null)
            inscrito
                ? const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check, size: 14, color: verdeOk),
                      SizedBox(width: 4),
                      Text('Inscrito',
                          style: TextStyle(fontSize: 11, color: verdeOk, fontWeight: FontWeight.w500)),
                    ],
                  )
                : InkWell(
                    onTap: onInscribirse,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: naranjaAcento,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text('Inscribirme',
                          style: TextStyle(fontSize: 11, color: Colors.white)),
                    ),
                  ),
        ],
      ),
    );
  }
}

// ===================== EXPLORAR =====================

class _Explorar extends StatefulWidget {
  final Future<List<OfertaAcademica>> academicas;
  final Future<List<OfertaLaboral>> laborales;
  final Future<List<Postulacion>> postulaciones;
  final Future<Set<int>> inscritos;
  final bool soloMiMunicipio;
  final Usuario usuario;
  final Future<void> Function(int) onPostularse;
  final Future<void> Function(int) onInscribirse;
  final int version;

  const _Explorar({
    required this.academicas,
    required this.laborales,
    required this.postulaciones,
    required this.inscritos,
    required this.soloMiMunicipio,
    required this.usuario,
    required this.onPostularse,
    required this.onInscribirse,
    required this.version,
  });

  @override
  State<_Explorar> createState() => _ExplorarState();
}

class _ExplorarState extends State<_Explorar> {
  String _consulta = '';
  String _filtro = 'todos';

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        const Text('Explorar', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          onChanged: (v) => setState(() => _consulta = v),
          decoration: const InputDecoration(
            hintText: 'Buscar por nombre, empresa o municipio...',
            prefixIcon: Icon(Icons.search),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            _chip('Todos', 'todos'),
            const SizedBox(width: 8),
            _chip('Académicas', 'academicas'),
            const SizedBox(width: 8),
            _chip('Laborales', 'laborales'),
          ],
        ),
        const SizedBox(height: 20),
        if (_filtro != 'laborales') ...[
          const Text('Oportunidades académicas',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 10),
          FutureBuilder<List<OfertaAcademica>>(
            future: widget.academicas,
            key: ValueKey('ea${widget.version}'),
            builder: (c, s) {
              if (!s.hasData) return const TextoVacio('Cargando...');
              final lista = s.data!
                  .where((o) =>
                      _consulta.isEmpty ||
                      o.nombre.toLowerCase().contains(_consulta.toLowerCase()) ||
                      o.descripcion.toLowerCase().contains(_consulta.toLowerCase()))
                  .toList();
              if (lista.isEmpty) return const TextoVacio('Sin resultados académicos para esa búsqueda.');
              return FutureBuilder<Set<int>>(
                future: widget.inscritos,
                builder: (c2, s2) {
                  final ids = s2.data ?? <int>{};
                  return Column(
                    children: [
                      for (final o in lista) ...[
                        _FilaAcademica(
                          item: o,
                          inscrito: ids.contains(o.id),
                          onInscribirse: () => widget.onInscribirse(o.id),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ],
                  );
                },
              );
            },
          ),
          const SizedBox(height: 10),
        ],
        if (_filtro != 'academicas') ...[
          const Text('Ofertas laborales', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 10),
          FutureBuilder<List<OfertaLaboral>>(
            future: widget.laborales,
            key: ValueKey('el${widget.version}'),
            builder: (c, s) {
              if (!s.hasData) return const TextoVacio('Cargando...');
              var lista = s.data!;
              if (widget.soloMiMunicipio) {
                lista = lista
                    .where((o) => o.ubicacion
                        .toLowerCase()
                        .contains(widget.usuario.municipio.toLowerCase()))
                    .toList();
              }
              lista = lista
                  .where((o) =>
                      _consulta.isEmpty ||
                      o.cargo.toLowerCase().contains(_consulta.toLowerCase()) ||
                      o.empresa.toLowerCase().contains(_consulta.toLowerCase()) ||
                      o.ubicacion.toLowerCase().contains(_consulta.toLowerCase()))
                  .toList();
              if (lista.isEmpty) return const TextoVacio('Sin resultados laborales para esa búsqueda.');
              return _listaLaborales(lista, widget.postulaciones, onPostularse: widget.onPostularse);
            },
          ),
        ],
      ],
    );
  }

  Widget _chip(String texto, String valor) {
    final sel = _filtro == valor;
    return InkWell(
      onTap: () => setState(() => _filtro = valor),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: sel ? azulOscuro : const Color(0xFFF1F2F4),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(texto,
            style: TextStyle(fontSize: 12, color: sel ? Colors.white : Colors.black)),
      ),
    );
  }
}

// ===================== MIS CURSOS =====================

class _MisCursos extends StatelessWidget {
  final Future<List<OfertaAcademica>> inscripciones;
  final Future<void> Function(int) onAnular;
  final VoidCallback onExplorar;
  final int version;

  const _MisCursos({
    required this.inscripciones,
    required this.onAnular,
    required this.onExplorar,
    required this.version,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        const Text('Mis cursos', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Cursos, becas y talleres en los que te has inscrito.',
            style: TextStyle(fontSize: 13, color: grisTexto)),
        const SizedBox(height: 16),
        FutureBuilder<List<OfertaAcademica>>(
          future: inscripciones,
          key: ValueKey('mc$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            if (s.data!.isEmpty) {
              return Column(
                children: [
                  const TextoVacio('Aún no te has inscrito en ningún curso.'),
                  FilledButton.tonal(
                    onPressed: onExplorar,
                    child: const Text('Ver oportunidades académicas'),
                  ),
                ],
              );
            }
            return Column(
              children: [
                for (final o in s.data!)
                  ...[
                    _FilaAcademica(
                      item: o,
                      onAnular: () => onAnular(o.id),
                    ),
                    const SizedBox(height: 10),
                  ],
              ],
            );
          },
        ),
      ],
    );
  }
}

// ===================== PERFIL =====================

class _Perfil extends StatelessWidget {
  final Usuario usuario;
  final String? fotoRuta;
  final Future<void> Function() onCambiarFoto;
  final VoidCallback onCerrarSesion;
  const _Perfil({
    required this.usuario,
    this.fotoRuta,
    required this.onCambiarFoto,
    required this.onCerrarSesion,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        const Text('Mi perfil', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Center(
          child: Stack(
            children: [
              _AvatarFoto(ruta: fotoRuta, radio: 40),
              Positioned(
                right: 0,
                bottom: 0,
                child: Material(
                  color: naranjaAcento,
                  shape: const CircleBorder(),
                  child: InkWell(
                    onTap: onCambiarFoto,
                    customBorder: const CircleBorder(),
                    child: const Padding(
                      padding: EdgeInsets.all(7),
                      child: Icon(Icons.camera_alt, size: 16, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: TextButton.icon(
            onPressed: onCambiarFoto,
            icon: const Icon(Icons.photo_library, size: 16),
            label: const Text('Cambiar foto de perfil', style: TextStyle(fontSize: 13)),
          ),
        ),
        Center(
          child: Text(usuario.nombreCompleto,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
        Center(
          child: Text(
            usuario.esAdministrador ? 'Administrador' : 'Estudiante',
            style: const TextStyle(fontSize: 12, color: naranjaAcento, fontWeight: FontWeight.w500),
          ),
        ),
        const SizedBox(height: 24),
        _dato(Icons.person, 'Perfil', usuario.esAdministrador ? 'Administrador' : usuario.tipoPerfil),
        const SizedBox(height: 10),
        _dato(Icons.email, 'Correo electrónico', usuario.correo),
        const SizedBox(height: 10),
        _dato(Icons.location_on, 'Municipio', usuario.municipio),
        const SizedBox(height: 28),
        FilledButton(
          onPressed: onCerrarSesion,
          style: FilledButton.styleFrom(backgroundColor: rojoCerrar),
          child: const Text('Cerrar sesión'),
        ),
      ],
    );
  }

  Widget _dato(IconData i, String etiqueta, String valor) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Icon(i, size: 20, color: azulOscuro),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(etiqueta, style: const TextStyle(fontSize: 11, color: grisTexto)),
              Text(valor, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
            ],
          ),
        ],
      ),
    );
  }
}

// ===================== SECCIONES DEL MENÚ =====================

class _SeccionBase extends StatelessWidget {
  final String titulo;
  final VoidCallback onVolver;
  final Widget child;

  const _SeccionBase({required this.titulo, required this.onVolver, required this.child});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        EncabezadoSeccion(titulo: titulo, onVolver: onVolver),
        const SizedBox(height: 16),
        child,
      ],
    );
  }
}

// Sección de ofertas académicas (cursos, becas, eventos) con botón de inscripción.
class _SeccionAcademica extends StatelessWidget {
  final String titulo;
  final VoidCallback onVolver;
  final Future<List<OfertaAcademica>> future;
  final Future<Set<int>> inscritos;
  final Future<void> Function(int) onInscribirse;
  final List<OfertaAcademica> Function(List<OfertaAcademica>)? filtrar;
  final String vacio;

  const _SeccionAcademica({
    required this.titulo,
    required this.onVolver,
    required this.future,
    required this.inscritos,
    required this.onInscribirse,
    this.filtrar,
    this.vacio = 'Todavía no hay oportunidades publicadas.',
  });

  @override
  Widget build(BuildContext context) {
    return _SeccionBase(
      titulo: titulo,
      onVolver: onVolver,
      child: FutureBuilder<List<OfertaAcademica>>(
        future: future,
        builder: (c, s) {
          if (!s.hasData) return const TextoVacio('Cargando...');
          var lista = filtrar != null ? filtrar!(s.data!) : s.data!;
          if (lista.isEmpty) return TextoVacio(vacio);
          return FutureBuilder<Set<int>>(
            future: inscritos,
            builder: (c2, s2) {
              final ids = s2.data ?? <int>{};
              return Column(
                children: [
                  for (final o in lista)
                    ...[
                      _FilaAcademica(
                        item: o,
                        inscrito: ids.contains(o.id),
                        onInscribirse: () => onInscribirse(o.id),
                      ),
                      const SizedBox(height: 10),
                    ],
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _SeccionOfertas extends StatelessWidget {
  final String titulo;
  final VoidCallback onVolver;
  final Future<List<OfertaLaboral>> future;
  final Future<List<Postulacion>> postulaciones;
  final Usuario usuario;
  final bool soloMiMunicipio;
  final bool recomendadas;
  final String? aviso;
  final Future<void> Function(int) onPostularse;

  const _SeccionOfertas({
    required this.titulo,
    required this.onVolver,
    required this.future,
    required this.postulaciones,
    required this.usuario,
    required this.soloMiMunicipio,
    this.recomendadas = false,
    this.aviso,
    required this.onPostularse,
  });

  @override
  Widget build(BuildContext context) {
    return _SeccionBase(
      titulo: titulo,
      onVolver: onVolver,
      child: FutureBuilder<List<OfertaLaboral>>(
        future: future,
        builder: (c, s) {
          if (!s.hasData) return const TextoVacio('Cargando...');
          var lista = s.data!;
          final mias = lista
              .where((o) => o.ubicacion.toLowerCase().contains(usuario.municipio.toLowerCase()))
              .toList();

          if (recomendadas) {
            lista = soloMiMunicipio ? mias : (mias.isEmpty ? lista : mias).take(5).toList();
          } else if (soloMiMunicipio) {
            lista = mias;
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (aviso != null) ...[
                Text(aviso!, style: const TextStyle(fontSize: 11, color: grisTexto)),
                const SizedBox(height: 10),
              ],
              if (lista.isEmpty)
                TextoVacio(recomendadas
                    ? 'Aún no tenemos recomendaciones para ti.'
                    : 'No hay ofertas laborales publicadas para tu municipio.')
              else
                _listaLaborales(lista, postulaciones, onPostularse: onPostularse),
            ],
          );
        },
      ),
    );
  }
}

class _Configuracion extends StatelessWidget {
  final VoidCallback onVolver;
  final bool soloMiMunicipio;
  final bool notificacionesActivas;
  final void Function(bool) onSoloMunicipio;
  final void Function(bool) onNotificaciones;
  final VoidCallback onCerrarSesion;

  const _Configuracion({
    required this.onVolver,
    required this.soloMiMunicipio,
    required this.notificacionesActivas,
    required this.onSoloMunicipio,
    required this.onNotificaciones,
    required this.onCerrarSesion,
  });

  @override
  Widget build(BuildContext context) {
    return _SeccionBase(
      titulo: 'Configuración',
      onVolver: onVolver,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Ajustes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 10),
          _ajuste(
            Icons.location_on,
            'Solo ver oportunidades de mi municipio',
            'Filtra las ofertas laborales en Explorar y Recomendadas.',
            soloMiMunicipio,
            onSoloMunicipio,
          ),
          _ajuste(
            Icons.notifications,
            'Notificaciones',
            'Activa o desactiva los avisos en la barra de Android.',
            notificacionesActivas,
            onNotificaciones,
          ),
          const SizedBox(height: 20),
          const Text('Cuenta', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: onCerrarSesion,
            style: FilledButton.styleFrom(backgroundColor: rojoCerrar),
            child: const Text('Cerrar sesión'),
          ),
        ],
      ),
    );
  }

  Widget _ajuste(IconData i, String t, String d, bool valor, void Function(bool) cambio) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Icon(i, size: 20, color: azulOscuro),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                Text(d, style: const TextStyle(fontSize: 11, color: grisTexto)),
              ],
            ),
          ),
          Switch(value: valor, onChanged: cambio),
        ],
      ),
    );
  }
}

// ===================== PANEL DEL ADMINISTRADOR =====================

class _InicioAdmin extends StatelessWidget {
  final Usuario usuario;
  final Future<List<OfertaAcademica>> academicas;
  final Future<List<OfertaLaboral>> laborales;
  final Future<List<PostulacionRecibida>> recibidas;
  final Future<int> totalUsuarios;
  final VoidCallback onMenu;
  final VoidCallback onNotificaciones;
  final VoidCallback onGestion;
  final VoidCallback onAlerta;
  final VoidCallback onVerRecibidas;
  final Future<void> Function(int, String) onCambiarEstado;
  final int version;

  const _InicioAdmin({
    required this.usuario,
    required this.academicas,
    required this.laborales,
    required this.recibidas,
    required this.totalUsuarios,
    required this.onMenu,
    required this.onNotificaciones,
    required this.onGestion,
    required this.onAlerta,
    required this.onVerRecibidas,
    required this.onCambiarEstado,
    required this.version,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        IconButton(
          onPressed: onMenu,
          icon: const Icon(Icons.menu),
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hola, ${usuario.nombre}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const Text('Panel del administrador',
                      style: TextStyle(fontSize: 12, color: grisTexto)),
                ],
              ),
            ),
            InkWell(
              onTap: onNotificaciones,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(color: Color(0xFFF1F2F4), shape: BoxShape.circle),
                child: const Icon(Icons.notifications, color: azulOscuro, size: 20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: FilledButton(
                onPressed: onGestion,
                style: FilledButton.styleFrom(backgroundColor: naranjaAcento),
                // FittedBox evita que el texto desborde el botón en pantallas angostas.
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.add, size: 18),
                      SizedBox(width: 6),
                      Text('Nueva oportunidad', style: TextStyle(fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: onAlerta,
                style: FilledButton.styleFrom(backgroundColor: azulOscuro),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.campaign, size: 18),
                      SizedBox(width: 6),
                      Text('Nueva alerta', style: TextStyle(fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
                child: _TarjetaResumen(
                    Icons.school, 'Cursos y becas', academicas.then((l) => l.length))),
            const SizedBox(width: 10),
            Expanded(
                child: _TarjetaResumen(
                    Icons.work, 'Ofertas laborales', laborales.then((l) => l.length))),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
                child: _TarjetaResumen(
                    Icons.mark_email_read, 'Postulaciones', recibidas.then((l) => l.length))),
            const SizedBox(width: 10),
            Expanded(child: _TarjetaResumen(Icons.people, 'Usuarios', totalUsuarios)),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Últimas postulaciones',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            InkWell(
              onTap: onVerRecibidas,
              borderRadius: BorderRadius.circular(6),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 2, horizontal: 4),
                child: Text('Ver todas', style: TextStyle(fontSize: 12, color: azulOscuro)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        FutureBuilder<List<PostulacionRecibida>>(
          future: recibidas,
          key: ValueKey('ad$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            if (s.data!.isEmpty) {
              return const TextoVacio('Nadie se ha postulado todavía.');
            }
            return Column(
              children: [
                for (final p in s.data!.take(3)) ...[
                  _FilaRecibida(postulacion: p, onCambiarEstado: onCambiarEstado),
                  const SizedBox(height: 10),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}

class _TarjetaResumen extends StatelessWidget {
  final IconData icono;
  final String etiqueta;
  final Future<int> valor;
  const _TarjetaResumen(this.icono, this.etiqueta, this.valor);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icono, color: naranjaAcento, size: 22),
          const SizedBox(height: 8),
          FutureBuilder<int>(
            future: valor,
            builder: (c, s) => Text(
              '${s.data ?? 0}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: azulOscuro),
            ),
          ),
          const SizedBox(height: 2),
          Text(etiqueta, style: const TextStyle(fontSize: 11, color: grisTexto)),
        ],
      ),
    );
  }
}

// ===================== POSTULACIONES RECIBIDAS (ADMIN) =====================

class _PostulacionesRecibidas extends StatelessWidget {
  final Future<List<PostulacionRecibida>> recibidas;
  final Future<void> Function(int, String) onCambiarEstado;
  final int version;

  const _PostulacionesRecibidas({
    required this.recibidas,
    required this.onCambiarEstado,
    required this.version,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      children: [
        const Text('Postulaciones recibidas',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Revisa las postulaciones de los estudiantes y cambia su estado.',
            style: TextStyle(fontSize: 13, color: grisTexto)),
        const SizedBox(height: 16),
        FutureBuilder<List<PostulacionRecibida>>(
          future: recibidas,
          key: ValueKey('pr$version'),
          builder: (c, s) {
            if (!s.hasData) return const TextoVacio('Cargando...');
            if (s.data!.isEmpty) return const TextoVacio('Nadie se ha postulado todavía.');
            return Column(
              children: [
                for (final p in s.data!) ...[
                  _FilaRecibida(postulacion: p, onCambiarEstado: onCambiarEstado),
                  const SizedBox(height: 10),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}

class _FilaRecibida extends StatelessWidget {
  final PostulacionRecibida postulacion;
  final Future<void> Function(int, String) onCambiarEstado;
  const _FilaRecibida({required this.postulacion, required this.onCambiarEstado});

  @override
  Widget build(BuildContext context) {
    final estado = postulacion.estado;
    final color = estado == 'Aceptada'
        ? verdeOk
        : estado == 'Rechazada'
            ? rojoCerrar
            : naranjaAcento;
    return InkWell(
      onTap: () => _mostrarOpciones(context),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: grisFondo, borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: const Color(0xFFE3E7ED),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.person, color: azulOscuro),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(postulacion.estudiante,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                  Text('${postulacion.cargo} • ${postulacion.empresa}',
                      style: const TextStyle(fontSize: 11, color: grisTexto)),
                  Text(postulacion.correo, style: const TextStyle(fontSize: 11, color: grisTexto)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(estado, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }

  void _mostrarOpciones(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(postulacion.estudiante, style: const TextStyle(fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${postulacion.cargo} • ${postulacion.empresa}',
                style: const TextStyle(fontSize: 13)),
            const SizedBox(height: 4),
            Text(postulacion.correo, style: const TextStyle(fontSize: 12, color: grisTexto)),
            const SizedBox(height: 14),
            const Text('Cambiar estado:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              onCambiarEstado(postulacion.id, 'Aceptada');
            },
            child: const Text('Aceptar', style: TextStyle(color: verdeOk)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              onCambiarEstado(postulacion.id, 'En revisión');
            },
            child: const Text('En revisión'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              onCambiarEstado(postulacion.id, 'Rechazada');
            },
            child: const Text('Rechazar', style: TextStyle(color: rojoCerrar)),
          ),
        ],
      ),
    );
  }
}

// ===================== PANELES =====================

class _PanelNotificaciones extends StatelessWidget {
  final List<Notificacion> notificaciones;
  final VoidCallback onCerrar;

  const _PanelNotificaciones({required this.notificaciones, required this.onCerrar});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Expanded(child: Text('Notificaciones', style: TextStyle(fontSize: 16))),
          IconButton(
            onPressed: onCerrar,
            icon: const Icon(Icons.close, size: 18, color: grisTexto),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
      contentPadding: const EdgeInsets.symmetric(vertical: 8),
      content: SizedBox(
        width: double.maxFinite,
        child: notificaciones.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: Text('No tienes notificaciones por ahora.',
                    style: TextStyle(fontSize: 13, color: grisTexto)),
              )
            : ListView(
                shrinkWrap: true,
                children: [for (final n in notificaciones) _fila(n)],
              ),
      ),
      actions: [
        TextButton(onPressed: onCerrar, child: const Text('Marcar como leídas y cerrar')),
      ],
    );
  }

  Widget _fila(Notificacion n) {
    return Container(
      color: n.leida ? Colors.transparent : const Color(0xFFFFF7EC),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: const BoxDecoration(color: Color(0xFFF1F2F4), shape: BoxShape.circle),
            child: Icon(iconoNotificacion(n.icono), size: 18, color: azulOscuro),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(n.titulo, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(n.mensaje, style: const TextStyle(fontSize: 12, color: grisTexto)),
                const SizedBox(height: 4),
                Text(tiempoRelativo(n.fechaMillis),
                    style: const TextStyle(fontSize: 11, color: Color(0xFFB0B0B0))),
              ],
            ),
          ),
          if (!n.leida)
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 8,
              height: 8,
              decoration: const BoxDecoration(color: naranjaAcento, shape: BoxShape.circle),
            ),
        ],
      ),
    );
  }
}

class _PanelPostulaciones extends StatelessWidget {
  final List<Postulacion> lista;
  const _PanelPostulaciones({required this.lista});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          const Expanded(child: Text('Mis Postulaciones', style: TextStyle(fontSize: 16))),
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.close, size: 18, color: grisTexto),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
      contentPadding: const EdgeInsets.symmetric(vertical: 8),
      content: SizedBox(
        width: double.maxFinite,
        child: lista.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: Text('Aún no te has postulado a ninguna oferta.',
                    style: TextStyle(fontSize: 13, color: grisTexto)),
              )
            : ListView(
                shrinkWrap: true,
                children: [
                  for (final p in lista)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${p.cargo} • ${p.empresa}',
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                          const SizedBox(height: 3),
                          Text('${fechaLarga(p.fechaMillis)} • ${p.estado}',
                              style: const TextStyle(fontSize: 11, color: grisTexto)),
                        ],
                      ),
                    ),
                ],
              ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
      ],
    );
  }
}

// Guarda los ajustes de Configuración en el teléfono.
class _PreferenciasConfig {
  bool soloMunicipio = false;
  bool notificaciones = true;

  static const _kSolo = 'solo_municipio';
  static const _kNoti = 'notificaciones';

  Future<void> cargar() async {
    final p = await SharedPreferences.getInstance();
    soloMunicipio = p.getBool(_kSolo) ?? false;
    notificaciones = p.getBool(_kNoti) ?? true;
  }

  Future<void> guardarSoloMunicipio(bool v) async {
    soloMunicipio = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kSolo, v);
  }

  Future<void> guardarNotificaciones(bool v) async {
    notificaciones = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kNoti, v);
  }
}
