import 'package:flutter/material.dart';
import 'tema.dart';

// Campo de texto con etiqueta arriba y una ayuda corta debajo.
class CampoTexto extends StatelessWidget {
  final String etiqueta;
  final String? ayuda;
  final TextEditingController? control;
  final String? Function(String?)? validador;
  final bool obscure;
  final TextInputType? teclado;
  final int maxLineas;
  final void Function(String)? onChanged;

  const CampoTexto({
    super.key,
    required this.etiqueta,
    this.ayuda,
    this.control,
    this.validador,
    this.obscure = false,
    this.teclado,
    this.maxLineas = 1,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(etiqueta, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        TextFormField(
          controller: control,
          validator: validador,
          obscureText: obscure,
          keyboardType: teclado,
          maxLines: obscure ? 1 : maxLineas,
          onChanged: onChanged,
          style: const TextStyle(fontSize: 14),
          decoration: InputDecoration(hintText: ayuda),
        ),
      ],
    );
  }
}

// Encabezado de sección: flecha para volver + título.
class EncabezadoSeccion extends StatelessWidget {
  final String titulo;
  final VoidCallback onVolver;
  final Widget? accion;

  const EncabezadoSeccion({super.key, required this.titulo, required this.onVolver, this.accion});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: onVolver,
          icon: const Icon(Icons.arrow_back, size: 22),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            titulo,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
        ),
        ?accion,
      ],
    );
  }
}

// Texto cuando una lista está vacía.
class TextoVacio extends StatelessWidget {
  final String texto;
  const TextoVacio(this.texto, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Text(texto, style: const TextStyle(fontSize: 13, color: grisTexto)),
    );
  }
}

// Ícono de una notificación según su clave.
IconData iconoNotificacion(String clave) {
  switch (clave) {
    case 'beca':
      return Icons.school;
    case 'empleo':
      return Icons.work;
    case 'postulacion':
      return Icons.description;
    case 'bienvenida':
      return Icons.emoji_events;
    default:
      return Icons.notifications;
  }
}

// "Hace 1 h", "Ayer"...
String tiempoRelativo(int millis) {
  if (millis <= 0) return '';
  final dif = DateTime.now().millisecondsSinceEpoch - millis;
  final min = dif ~/ 60000;
  final horas = dif ~/ 3600000;
  final dias = dif ~/ 86400000;
  if (min < 1) return 'Justo ahora';
  if (min < 60) return 'Hace $min min';
  if (horas < 24) return 'Hace $horas h';
  if (dias < 2) return 'Ayer';
  return 'Hace $dias días';
}

String fechaLarga(int millis) {
  if (millis <= 0) return '';
  final f = DateTime.fromMillisecondsSinceEpoch(millis);
  const meses = [
    'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
    'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
  ];
  return '${f.day} de ${meses[f.month - 1]}, ${f.year}';
}
