package com.daniela.bolivar_aprende_y_trabaja

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
