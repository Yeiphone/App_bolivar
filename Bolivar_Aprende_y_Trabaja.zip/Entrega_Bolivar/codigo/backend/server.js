// API REST de Bolívar Aprende y Trabaja (Node.js + Express).
// CRUD completo (GET, POST, PUT, DELETE) de ofertas académicas y laborales,
// más los recursos que usa la app: usuarios, postulaciones, inscripciones y notificaciones.
const express = require('express');
const cors = require('cors');
const almacen = require('./almacen');

const app = express();
app.use(cors());
app.use(express.json());

app.use((req, _res, next) => {
  console.log(`${new Date().toLocaleTimeString()}  ${req.method} ${req.originalUrl}`);
  next();
});

const d = () => almacen.datos;
const ahoraMs = () => String(Date.now());
const texto = (v) => (v === undefined || v === null ? '' : String(v).trim());
const sinPassword = ({ password, ...resto }) => resto;

function notificar(usuario_id, titulo, icono, mensaje) {
  d().notificaciones.push({
    id: almacen.siguienteId('notificaciones'),
    usuario_id, titulo, icono, mensaje, fechaEnvio: ahoraMs(), leida: 0,
  });
}

function avisarAdmins(excluirId, titulo, icono, mensaje) {
  d().usuarios
    .filter((u) => u.esAdministrador === 1 && u.id !== excluirId)
    .forEach((a) => notificar(a.id, titulo, icono, mensaje));
}

// Genera el CRUD (GET lista, GET uno, POST, PUT, DELETE) de una colección.
function crud(ruta, tabla, camposObligatorios, camposPermitidos) {
  const router = express.Router();

  router.get('/', (_req, res) => res.json([...d()[tabla]].reverse()));

  router.get('/:id', (req, res) => {
    const item = d()[tabla].find((x) => x.id === Number(req.params.id));
    if (!item) return res.status(404).json({ error: 'No encontrado' });
    res.json(item);
  });

  router.post('/', (req, res) => {
    const faltan = camposObligatorios.filter((c) => !texto(req.body[c]));
    if (faltan.length) return res.status(400).json({ error: `Faltan campos: ${faltan.join(', ')}` });
    const item = { id: almacen.siguienteId(tabla) };
    camposPermitidos.forEach((c) => {
      item[c] = c === 'cupos' ? Number(req.body[c]) || 0 : texto(req.body[c]);
    });
    d()[tabla].push(item);
    almacen.guardar();
    res.status(201).json(item);
  });

  router.put('/:id', (req, res) => {
    const item = d()[tabla].find((x) => x.id === Number(req.params.id));
    if (!item) return res.status(404).json({ error: 'No encontrado' });
    const faltan = camposObligatorios.filter((c) => req.body[c] !== undefined && !texto(req.body[c]));
    if (faltan.length) return res.status(400).json({ error: `Campos vacíos: ${faltan.join(', ')}` });
    camposPermitidos.forEach((c) => {
      if (req.body[c] !== undefined) item[c] = c === 'cupos' ? Number(req.body[c]) || 0 : texto(req.body[c]);
    });
    almacen.guardar();
    res.json(item);
  });

  router.delete('/:id', (req, res) => {
    const i = d()[tabla].findIndex((x) => x.id === Number(req.params.id));
    if (i < 0) return res.status(404).json({ error: 'No encontrado' });
    const [borrado] = d()[tabla].splice(i, 1);
    almacen.guardar();
    res.json({ eliminado: true, item: borrado });
  });

  app.use(ruta, router);
}

// ---------- Ofertas académicas y laborales (CRUD) ----------
crud('/api/ofertas-academicas', 'academicas', ['nombre'], ['nombre', 'descripcion', 'requisitos', 'cupos']);
crud('/api/ofertas-laborales', 'laborales', ['empresa', 'cargo'],
  ['empresa', 'cargo', 'descripcion', 'requisitos', 'ubicacion', 'salario', 'fecha_publicacion', 'contacto']);

// ---------- Usuarios ----------
app.post('/api/auth/login', (req, res) => {
  const correo = texto(req.body.correo).toLowerCase();
  const password = texto(req.body.password);
  const u = d().usuarios.find((x) => x.correo.toLowerCase() === correo && x.password.trim() === password);
  if (!u) return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
  res.json(sinPassword(u));
});

app.get('/api/usuarios', (_req, res) => res.json(d().usuarios.map(sinPassword)));

app.get('/api/usuarios/:id', (req, res) => {
  const u = d().usuarios.find((x) => x.id === Number(req.params.id));
  if (!u) return res.status(404).json({ error: 'No encontrado' });
  res.json(sinPassword(u));
});

app.post('/api/usuarios', (req, res) => {
  const b = req.body;
  if (!texto(b.nombre) || !texto(b.correo) || !texto(b.password)) {
    return res.status(400).json({ error: 'Nombre, correo y contraseña son obligatorios' });
  }
  if (d().usuarios.some((u) => u.correo.toLowerCase() === texto(b.correo).toLowerCase())) {
    return res.status(409).json({ error: 'Ese correo ya está registrado' });
  }
  const u = {
    id: almacen.siguienteId('usuarios'),
    nombre: texto(b.nombre), apellido: texto(b.apellido), identificacion: texto(b.identificacion),
    correo: texto(b.correo), telefono: texto(b.telefono), municipio: texto(b.municipio),
    password: String(b.password), tipoPerfil: texto(b.tipoPerfil) || 'Estudiante',
    esAdministrador: 0, fechaRegistro: ahoraMs(),
  };
  d().usuarios.push(u);
  notificar(u.id, 'Bienvenido a Bolívar Aprende y Trabaja', 'bienvenida',
    'Tu cuenta fue creada correctamente. Ya puedes explorar oportunidades académicas y laborales.');
  almacen.guardar();
  res.status(201).json(sinPassword(u));
});

app.put('/api/usuarios/:id', (req, res) => {
  const u = d().usuarios.find((x) => x.id === Number(req.params.id));
  if (!u) return res.status(404).json({ error: 'No encontrado' });
  ['nombre', 'apellido', 'identificacion', 'telefono', 'municipio', 'tipoPerfil'].forEach((c) => {
    if (req.body[c] !== undefined) u[c] = texto(req.body[c]);
  });
  almacen.guardar();
  res.json(sinPassword(u));
});

app.delete('/api/usuarios/:id', (req, res) => {
  const id = Number(req.params.id);
  if (id === 1) return res.status(400).json({ error: 'No se puede eliminar al administrador principal' });
  const i = d().usuarios.findIndex((x) => x.id === id);
  if (i < 0) return res.status(404).json({ error: 'No encontrado' });
  d().usuarios.splice(i, 1);
  almacen.guardar();
  res.json({ eliminado: true });
});

// ---------- Postulaciones ----------
function armarPostulacion(p) {
  const o = d().laborales.find((x) => x.id === p.oferta_id);
  const u = d().usuarios.find((x) => x.id === p.usuario_id);
  return {
    ...p,
    empresa: o ? o.empresa : '',
    cargo: o ? o.cargo : '',
    estudiante: u ? `${u.nombre} ${u.apellido || ''}`.trim() : '',
    correo: u ? u.correo : '',
  };
}

// GET /api/postulaciones            -> todas (administrador)
// GET /api/postulaciones?usuarioId=2 -> las de un usuario
app.get('/api/postulaciones', (req, res) => {
  let lista = d().postulaciones;
  if (req.query.usuarioId) lista = lista.filter((p) => p.usuario_id === Number(req.query.usuarioId));
  res.json([...lista].reverse().filter((p) => d().laborales.some((o) => o.id === p.oferta_id)).map(armarPostulacion));
});

app.post('/api/postulaciones', (req, res) => {
  const usuario_id = Number(req.body.usuario_id);
  const oferta_id = Number(req.body.oferta_id);
  const oferta = d().laborales.find((o) => o.id === oferta_id);
  const usuario = d().usuarios.find((u) => u.id === usuario_id);
  if (!oferta || !usuario) return res.status(404).json({ error: 'Usuario u oferta no existe' });
  if (d().postulaciones.some((p) => p.usuario_id === usuario_id && p.oferta_id === oferta_id)) {
    return res.status(409).json({ error: 'Ya te postulaste a esta oferta' });
  }
  const p = {
    id: almacen.siguienteId('postulaciones'), usuario_id, oferta_id,
    fecha_postulacion: ahoraMs(), estado: 'Enviada',
  };
  d().postulaciones.push(p);
  notificar(usuario_id, 'Postulación enviada', 'postulacion',
    `Tu postulación a "${oferta.cargo}" en ${oferta.empresa} fue registrada correctamente.`);
  avisarAdmins(usuario_id, 'Nueva postulación recibida', 'postulacion',
    `${usuario.nombre} se postuló a "${oferta.cargo}" en ${oferta.empresa}.`);
  almacen.guardar();
  res.status(201).json(armarPostulacion(p));
});

app.put('/api/postulaciones/:id', (req, res) => {
  const p = d().postulaciones.find((x) => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'No encontrado' });
  const estado = texto(req.body.estado);
  if (!estado) return res.status(400).json({ error: 'Falta el estado' });
  p.estado = estado;
  notificar(p.usuario_id, `Postulación ${estado}`, 'postulacion',
    estado === 'Aceptada'
      ? '¡Felicidades! Tu postulación fue aceptada. Revisa el contacto de la oferta.'
      : `Tu postulación fue revisada. Estado: ${estado}.`);
  almacen.guardar();
  res.json(armarPostulacion(p));
});

app.delete('/api/postulaciones/:id', (req, res) => {
  const i = d().postulaciones.findIndex((x) => x.id === Number(req.params.id));
  if (i < 0) return res.status(404).json({ error: 'No encontrado' });
  d().postulaciones.splice(i, 1);
  almacen.guardar();
  res.json({ eliminado: true });
});

// ---------- Inscripciones ----------
// GET /api/inscripciones?usuarioId=2 -> ofertas académicas en las que está inscrito
app.get('/api/inscripciones', (req, res) => {
  let lista = d().inscripciones;
  if (req.query.usuarioId) lista = lista.filter((i) => i.usuario_id === Number(req.query.usuarioId));
  res.json([...lista].reverse().map((i) => ({
    ...i,
    oferta: d().academicas.find((a) => a.id === i.oferta_id) || null,
  })).filter((i) => i.oferta));
});

app.post('/api/inscripciones', (req, res) => {
  const usuario_id = Number(req.body.usuario_id);
  const oferta_id = Number(req.body.oferta_id);
  const curso = d().academicas.find((a) => a.id === oferta_id);
  if (!curso || !d().usuarios.some((u) => u.id === usuario_id)) {
    return res.status(404).json({ error: 'Usuario u oferta no existe' });
  }
  if (d().inscripciones.some((i) => i.usuario_id === usuario_id && i.oferta_id === oferta_id)) {
    return res.status(409).json({ error: 'Ya estás inscrito' });
  }
  const i = {
    id: almacen.siguienteId('inscripciones'), usuario_id, oferta_id,
    fecha_inscripcion: ahoraMs(), estado: 'Inscrito',
  };
  d().inscripciones.push(i);
  notificar(usuario_id, 'Inscripción registrada', 'beca', `Tu inscripción a "${curso.nombre}" fue registrada correctamente.`);
  avisarAdmins(usuario_id, 'Nueva inscripción', 'beca', `Un estudiante se inscribió en "${curso.nombre}".`);
  almacen.guardar();
  res.status(201).json(i);
});

app.delete('/api/inscripciones', (req, res) => {
  const usuario_id = Number(req.query.usuarioId);
  const oferta_id = Number(req.query.ofertaId);
  const i = d().inscripciones.findIndex((x) => x.usuario_id === usuario_id && x.oferta_id === oferta_id);
  if (i < 0) return res.status(404).json({ error: 'No encontrado' });
  d().inscripciones.splice(i, 1);
  almacen.guardar();
  res.json({ eliminado: true });
});

// ---------- Notificaciones ----------
// GET /api/notificaciones                -> recientes de todos (panel del admin)
// GET /api/notificaciones?usuarioId=2    -> las de un usuario
app.get('/api/notificaciones', (req, res) => {
  let lista = d().notificaciones;
  if (req.query.usuarioId) lista = lista.filter((n) => n.usuario_id === Number(req.query.usuarioId));
  lista = [...lista].reverse();
  if (req.query.limite) lista = lista.slice(0, Number(req.query.limite));
  res.json(lista);
});

app.post('/api/notificaciones', (req, res) => {
  const { usuario_id, titulo, mensaje, icono } = req.body;
  if (!texto(titulo) || !texto(mensaje)) return res.status(400).json({ error: 'Título y mensaje son obligatorios' });
  if (!d().usuarios.some((u) => u.id === Number(usuario_id))) return res.status(404).json({ error: 'Usuario no existe' });
  notificar(Number(usuario_id), texto(titulo), texto(icono) || 'notificacion', texto(mensaje));
  almacen.guardar();
  res.status(201).json(d().notificaciones[d().notificaciones.length - 1]);
});

app.post('/api/notificaciones/todos', (req, res) => {
  const { titulo, mensaje, icono } = req.body;
  if (!texto(titulo) || !texto(mensaje)) return res.status(400).json({ error: 'Título y mensaje son obligatorios' });
  d().usuarios.forEach((u) => notificar(u.id, texto(titulo), texto(icono) || 'notificacion', texto(mensaje)));
  almacen.guardar();
  res.status(201).json({ enviadas: d().usuarios.length });
});

// Marca como leídas todas las notificaciones de un usuario.
app.put('/api/notificaciones/leidas', (req, res) => {
  const usuarioId = Number(req.query.usuarioId);
  d().notificaciones.filter((n) => n.usuario_id === usuarioId).forEach((n) => { n.leida = 1; });
  almacen.guardar();
  res.json({ ok: true });
});

app.delete('/api/notificaciones/:id', (req, res) => {
  const i = d().notificaciones.findIndex((x) => x.id === Number(req.params.id));
  if (i < 0) return res.status(404).json({ error: 'No encontrado' });
  d().notificaciones.splice(i, 1);
  almacen.guardar();
  res.json({ eliminado: true });
});

app.get('/', (_req, res) => res.json({ api: 'Bolívar Aprende y Trabaja', estado: 'en línea' }));

app.use((_req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));

const PUERTO = process.env.PORT || 3000;
app.listen(PUERTO, '0.0.0.0', () => {
  console.log(`API lista en http://localhost:${PUERTO}`);
});
