// Almacén de datos en arreglos (en memoria) con respaldo en un archivo JSON.
// Así los datos no se pierden al reiniciar el servidor.
const fs = require('fs');
const path = require('path');

const ARCHIVO = path.join(__dirname, 'data', 'datos.json');

function inicial() {
  const hoy = new Date().toISOString().substring(0, 10);
  const ahora = String(Date.now());
  return {
    contadores: { usuarios: 1, academicas: 2, laborales: 4, postulaciones: 0, inscripciones: 0, notificaciones: 2 },
    usuarios: [
      {
        id: 1, nombre: 'Admin', apellido: 'Bolívar', identificacion: '0000',
        correo: 'admin@bolivar.com', telefono: '', municipio: 'Cartagena de Indias',
        password: 'admin123', tipoPerfil: 'Profesional', esAdministrador: 1,
        fechaRegistro: ahora,
      },
    ],
    academicas: [
      { id: 1, nombre: 'Desarrollo Web Frontend', descripcion: 'Beca 100% - Tecnológico de Bolívar', requisitos: 'Ninguno, curso para principiantes', cupos: 30 },
      { id: 2, nombre: 'Inglés para Negocios', descripcion: 'Gratuito - SENA Bolívar', requisitos: 'Nivel A2 en adelante', cupos: 25 },
    ],
    laborales: [
      { id: 1, empresa: 'Agencia Creativa Heroica', cargo: 'Asistente de Marketing Digital', descripcion: 'Apoyo en campañas y redes sociales', requisitos: 'Estudiante o técnico en mercadeo', ubicacion: 'Cartagena', salario: '$1.5M - $1.8M COP', fecha_publicacion: hoy, contacto: 'contacto@agenciaheroica.co' },
      { id: 2, empresa: 'Bolívar Tech Solutions', cargo: 'Desarrollo Frontend Junior', descripcion: 'Mantenimiento de aplicaciones web', requisitos: 'Conocimientos en HTML, CSS y JavaScript', ubicacion: 'Turbaco (Híbrido)', salario: '$2.2M - $2.6M COP', fecha_publicacion: hoy, contacto: 'empleo@bolivartech.co' },
      { id: 3, empresa: 'Cámara de Comercio', cargo: 'Soporte Técnico', descripcion: 'Atención de incidencias de hardware y software', requisitos: 'Técnico en sistemas', ubicacion: 'Cartagena', salario: '$1.3M COP', fecha_publicacion: hoy, contacto: 'rrhh@camaracartagena.co' },
      { id: 4, empresa: 'Fundación Bolívar', cargo: 'Gestor de Proyectos Sociales', descripcion: 'Coordinación de proyectos comunitarios', requisitos: 'Experiencia en trabajo social', ubicacion: 'Arjona', salario: '$1.8M COP', fecha_publicacion: hoy, contacto: 'proyectos@fundacionbolivar.org' },
    ],
    postulaciones: [],
    inscripciones: [],
    notificaciones: [
      { id: 1, usuario_id: 1, titulo: 'Nueva beca disponible', icono: 'beca', mensaje: 'Se publicó una beca 100% en Desarrollo Web Frontend.', fechaEnvio: ahora, leida: 0 },
      { id: 2, usuario_id: 1, titulo: 'Actualización de postulación', icono: 'empleo', mensaje: 'Revisa las nuevas ofertas laborales publicadas esta semana.', fechaEnvio: ahora, leida: 1 },
    ],
  };
}

let db;

function cargar() {
  try {
    db = JSON.parse(fs.readFileSync(ARCHIVO, 'utf8'));
  } catch (_) {
    db = inicial();
    guardar();
  }
}

function guardar() {
  fs.mkdirSync(path.dirname(ARCHIVO), { recursive: true });
  fs.writeFileSync(ARCHIVO, JSON.stringify(db, null, 2));
}

function siguienteId(tabla) {
  db.contadores[tabla] = (db.contadores[tabla] || 0) + 1;
  return db.contadores[tabla];
}

cargar();

module.exports = {
  get datos() { return db; },
  guardar,
  siguienteId,
};
