# API Bolívar Aprende y Trabaja (Node.js + Express)

Datos guardados en **arreglos en memoria** con respaldo automático en `data/datos.json`
(no se pierden al reiniciar el servidor).

## Ejecutar
```bash
cd codigo/backend
npm install
npm start          # http://localhost:3000
```

## CRUD principal (ofertas)
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/ofertas-academicas` | Listar |
| GET | `/api/ofertas-academicas/:id` | Obtener una |
| POST | `/api/ofertas-academicas` | Crear `{nombre, descripcion, requisitos, cupos}` |
| PUT | `/api/ofertas-academicas/:id` | Actualizar |
| DELETE | `/api/ofertas-academicas/:id` | Eliminar |
| GET / POST / PUT / DELETE | `/api/ofertas-laborales[/:id]` | Igual, con `{empresa, cargo, descripcion, requisitos, ubicacion, salario, fecha_publicacion, contacto}` |

## Otros recursos que usa la app
| Método | Ruta | Descripción |
|---|---|---|
| POST | `/api/auth/login` | Iniciar sesión `{correo, password}` |
| GET / POST | `/api/usuarios` | Listar / registrar |
| GET / PUT / DELETE | `/api/usuarios/:id` | Ver / editar / eliminar |
| GET | `/api/postulaciones[?usuarioId=]` | Todas o las de un usuario |
| POST | `/api/postulaciones` | `{usuario_id, oferta_id}` |
| PUT | `/api/postulaciones/:id` | Cambiar estado `{estado}` |
| DELETE | `/api/postulaciones/:id` | Eliminar |
| GET | `/api/inscripciones?usuarioId=` | Inscripciones de un usuario |
| POST | `/api/inscripciones` | `{usuario_id, oferta_id}` |
| DELETE | `/api/inscripciones?usuarioId=&ofertaId=` | Anular |
| GET | `/api/notificaciones[?usuarioId=&limite=]` | Listar |
| POST | `/api/notificaciones` / `/api/notificaciones/todos` | Enviar a uno / a todos |
| PUT | `/api/notificaciones/leidas?usuarioId=` | Marcar leídas |
| DELETE | `/api/notificaciones/:id` | Eliminar |

Códigos: 200/201 OK, 400 datos inválidos, 401 credenciales, 404 no existe, 409 duplicado.
